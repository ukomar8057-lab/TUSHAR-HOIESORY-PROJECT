export default function ShopLoading() {
  return (
    <div className="mx-auto max-w-[1600px] px-4 py-16 sm:px-8 sm:py-24">
      <div className="h-3 w-24 bg-ink/10" />
      <div className="mt-8 h-12 w-2/3 max-w-md bg-ink/10" />
      <div className="mt-8 h-3 w-full max-w-xl bg-ink/10" />
      <div className="mt-16 grid grid-cols-2 gap-x-4 gap-y-14 md:grid-cols-3 lg:grid-cols-4">
        {Array.from({ length: 8 }).map((_, index) => (
          <div key={index}>
            <div className="aspect-[3/4] w-full animate-pulse bg-shell" />
            <div className="mt-4 h-3 w-3/4 bg-ink/10" />
            <div className="mt-3 h-2 w-1/2 bg-ink/10" />
          </div>
        ))}
      </div>
    </div>
  );
}
