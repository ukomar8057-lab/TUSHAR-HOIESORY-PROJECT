import type { Metadata } from "next";
import Link from "next/link";
import FilterBar from "@/components/filter-bar";
import ProductCard from "@/components/product-card";
import { CATEGORY_LABELS, listCollections, listProducts } from "@/lib/catalog";

export const metadata: Metadata = {
  title: "Shop all legwear",
  description: "Socks, tights, leggings and thermals knitted in Tiruppur.",
};

type SearchParams = Record<string, string | string[] | undefined>;

function single(value: string | string[] | undefined): string | undefined {
  if (Array.isArray(value)) return value[0];
  return value ?? undefined;
}

export default async function ShopPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const params = await searchParams;
  const filters = {
    category: single(params.category),
    audience: single(params.audience),
    collection: single(params.collection),
    q: single(params.q),
    sort: single(params.sort),
  };

  const [products, collections] = await Promise.all([
    listProducts(filters),
    listCollections(),
  ]);

  const heading = filters.q
    ? `Search: ${filters.q}`
    : filters.category
      ? (CATEGORY_LABELS[filters.category] ?? "Shop")
      : filters.collection
        ? (collections.find((c) => c.slug === filters.collection)?.title ?? "Shop")
        : filters.audience
          ? `${filters.audience[0].toUpperCase()}${filters.audience.slice(1)}'s legwear`
          : "Everything we make";

  return (
    <div>
      <section className="mx-auto max-w-[1600px] px-4 pb-10 pt-14 sm:px-8 sm:pt-20">
        <nav className="label-xs flex items-center gap-2 text-stone">
          <Link href="/" className="hover:text-ink">
            Home
          </Link>
          <span>/</span>
          <span className="text-graphite">{heading}</span>
        </nav>
        <h1 className="display-lg mt-6">{heading}</h1>
        <p className="mt-5 max-w-2xl text-sm leading-relaxed text-graphite">
          {filters.collection
            ? (collections.find((c) => c.slug === filters.collection)?.description ??
              "Knitted in Tiruppur in small batches.")
            : "Small-batch hosiery knitted on vintage circular frames. Filter by type, wearer or collection — every piece ships within twenty-four hours."}
        </p>
      </section>

      <FilterBar collections={collections} active={filters} total={products.length} />

      <section className="mx-auto max-w-[1600px] px-4 py-14 sm:px-8">
        {products.length === 0 ? (
          <div className="border border-dashed border-ink/20 px-6 py-24 text-center">
            <p className="display-md text-ink">Nothing here yet.</p>
            <p className="mx-auto mt-4 max-w-md text-sm text-graphite">
              We knit in small runs, so pieces move in and out quickly. Try a different filter or
              browse everything we currently have on the floor.
            </p>
            <Link
              href="/shop"
              className="label-sm mt-8 inline-block bg-ink px-8 py-4 text-bone hover:bg-henna"
            >
              Browse everything
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-x-4 gap-y-14 md:grid-cols-3 lg:grid-cols-4">
            {products.map((product, index) => (
              <ProductCard key={product.id} product={product} priority={index < 4} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
