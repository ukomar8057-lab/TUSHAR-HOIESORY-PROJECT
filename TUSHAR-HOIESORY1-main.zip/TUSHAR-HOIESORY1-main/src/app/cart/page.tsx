import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import ProductCard from "@/components/product-card";
import { removeLineAction, updateQuantityAction } from "@/app/actions";
import { getCartSummary } from "@/lib/cart";
import { getFeaturedProducts } from "@/lib/catalog";
import { formatPrice, freeShippingThreshold } from "@/lib/format";

export const metadata: Metadata = { title: "Your bag" };

export default async function CartPage() {
  const [cart, recommended] = await Promise.all([getCartSummary(), getFeaturedProducts(4)]);
  const threshold = freeShippingThreshold();
  const progress = Math.min(100, Math.round((cart.subtotalCents / threshold) * 100));

  return (
    <div className="mx-auto max-w-[1600px] px-4 py-14 sm:px-8 sm:py-20">
      <nav className="label-xs flex items-center gap-2 text-stone">
        <Link href="/" className="hover:text-ink">Home</Link>
        <span>/</span>
        <span className="text-graphite">Bag</span>
      </nav>
      <h1 className="display-lg mt-6">Your bag</h1>

      {cart.lines.length === 0 ? (
        <div className="mt-12 border border-dashed border-ink/20 px-6 py-24 text-center">
          <p className="display-md">Your bag is empty.</p>
          <p className="mx-auto mt-4 max-w-md text-sm text-graphite">
            Start with the house favourite — a dense 3x1 rib crew knitted in Tiruppur.
          </p>
          <Link
            href="/shop"
            className="label-sm mt-8 inline-block bg-ink px-8 py-4 text-bone hover:bg-henna"
          >
            Shop the collection
          </Link>
        </div>
      ) : (
        <div className="mt-12 grid gap-12 lg:grid-cols-[1.6fr_1fr] lg:gap-16">
          <div>
            <div className="hidden border-b border-ink/15 pb-4 sm:grid sm:grid-cols-[1.8fr_auto_auto] sm:gap-6">
              <span className="label-xs text-stone">Piece</span>
              <span className="label-xs text-stone">Quantity</span>
              <span className="label-xs text-right text-stone">Total</span>
            </div>

            <ul className="divide-y divide-ink/10">
              {cart.lines.map((line) => (
                <li key={line.itemId} className="grid gap-6 py-6 sm:grid-cols-[1.8fr_auto_auto] sm:gap-6">
                  <div className="flex gap-5">
                    <Link
                      href={`/product/${line.product.slug}`}
                      className="relative h-32 w-24 shrink-0 overflow-hidden bg-shell"
                    >
                      <Image
                        src={line.product.images[0]}
                        alt={line.product.name}
                        fill
                        sizes="120px"
                        className="object-cover"
                      />
                    </Link>
                    <div className="flex flex-col">
                      <Link href={`/product/${line.product.slug}`} className="text-sm font-medium hover:text-henna">
                        {line.product.name}
                      </Link>
                      <p className="mt-1 text-[11px] text-stone">{line.product.tagline}</p>
                      <p className="mt-2 text-[11px] text-graphite">
                        Size {line.size} · {line.product.colorName}
                      </p>
                      <p className="mt-1 text-[11px] text-stone">{formatPrice(line.product.priceCents)} each</p>
                      <form action={removeLineAction} className="mt-auto pt-3">
                        <input type="hidden" name="itemId" value={line.itemId} />
                        <button type="submit" className="label-xs text-stone link-underline hover:text-henna">
                          Remove
                        </button>
                      </form>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="flex items-center border border-ink/20">
                      <form action={updateQuantityAction}>
                        <input type="hidden" name="itemId" value={line.itemId} />
                        <input type="hidden" name="delta" value={-1} />
                        <button
                          type="submit"
                          aria-label="Decrease quantity"
                          className="px-3 py-2 text-sm text-graphite hover:text-ink"
                        >
                          −
                        </button>
                      </form>
                      <span className="w-8 text-center text-sm">{line.quantity}</span>
                      <form action={updateQuantityAction}>
                        <input type="hidden" name="itemId" value={line.itemId} />
                        <input type="hidden" name="delta" value={1} />
                        <button
                          type="submit"
                          aria-label="Increase quantity"
                          className="px-3 py-2 text-sm text-graphite hover:text-ink"
                        >
                          +
                        </button>
                      </form>
                    </div>
                  </div>

                  <p className="text-sm sm:text-right">{formatPrice(line.lineTotalCents)}</p>
                </li>
              ))}
            </ul>

            <Link href="/shop" className="label-xs mt-8 inline-block text-henna link-underline">
              ← Continue shopping
            </Link>
          </div>

          <aside className="lg:sticky lg:top-[168px] lg:self-start">
            <div className="border border-ink/15 p-7">
              <p className="label-xs text-stone">Order summary</p>

              <div className="mt-6 space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-graphite">Subtotal ({cart.itemCount} items)</span>
                  <span>{formatPrice(cart.subtotalCents)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-graphite">Shipping</span>
                  <span>{cart.shippingCents === 0 ? "Free" : formatPrice(cart.shippingCents)}</span>
                </div>
              </div>

              <div className="mt-6 border-t border-ink/15 pt-5">
                <div className="flex items-baseline justify-between">
                  <span className="label-xs text-graphite">Total</span>
                  <span className="font-display text-3xl">{formatPrice(cart.totalCents)}</span>
                </div>
                <p className="mt-2 text-[11px] text-stone">Inclusive of all taxes</p>
              </div>

              {cart.remainingForFreeShipping > 0 ? (
                <div className="mt-6">
                  <div className="h-[3px] w-full bg-ink/10">
                    <div className="h-full bg-henna" style={{ width: `${progress}%` }} />
                  </div>
                  <p className="mt-3 text-[11px] text-graphite">
                    Add {formatPrice(cart.remainingForFreeShipping)} more for free shipping.
                  </p>
                </div>
              ) : (
                <p className="mt-6 text-[11px] text-moss">Free shipping unlocked.</p>
              )}

              <Link
                href="/checkout"
                className="label-sm mt-7 block bg-ink px-8 py-5 text-center text-bone transition-colors hover:bg-henna"
              >
                Checkout
              </Link>
              <p className="mt-4 text-center text-[11px] text-stone">
                UPI · Cards · Net banking · Cash on delivery
              </p>
            </div>
          </aside>
        </div>
      )}

      {recommended.length > 0 && (
        <section className="mt-24 border-t border-ink/10 pt-16">
          <p className="label-xs text-stone">Most worn</p>
          <h2 className="display-md mt-4">Pairs well with your bag</h2>
          <div className="mt-10 grid grid-cols-2 gap-x-4 gap-y-12 lg:grid-cols-4">
            {recommended.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
