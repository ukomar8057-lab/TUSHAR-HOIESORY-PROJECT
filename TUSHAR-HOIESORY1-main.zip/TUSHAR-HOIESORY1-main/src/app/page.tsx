import Image from "next/image";
import Link from "next/link";
import ProductCard from "@/components/product-card";
import NewsletterForm from "@/components/newsletter-form";
import FeaturedCategoriesGrid from "@/components/featured-categories-grid";
import {
  CATEGORY_LABELS,
  getCatalogCounts,
  getFeaturedProducts,
  getNewArrivals,
  listCollections,
} from "@/lib/catalog";

const categoryTiles = [
  { key: "tshirts", image: "https://images.pexels.com/photos/9775825/pexels-photo-9775825.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", copy: "Heavyweight combed cotton single jersey" },
  { key: "shirts", image: "https://images.pexels.com/photos/9775674/pexels-photo-9775674.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", copy: "Fine-gauge knit oxford & casual shirts" },
  { key: "hoodies", image: "https://images.pexels.com/photos/28701960/pexels-photo-28701960.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", copy: "420 GSM loopback French terry fleece" },
  { key: "jackets", image: "https://images.pexels.com/photos/9604298/pexels-photo-9604298.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", copy: "Heritage chore jackets & utility outerwear" },
];

const promises = [
  { label: "Free shipping", copy: "On every order above ₹3,000" },
  { label: "Since 1978", copy: "One mill, three generations" },
  { label: "Combed Cotton", copy: "260+ GSM structured fabrics" },
  { label: "30-day returns", copy: "Worn or unworn, no questions" },
];

const testimonials = [
  {
    quote:
      "The Heavyweight Combed Tee is the best T-shirt I have rebought. Holds its structure perfectly after twenty washes.",
    name: "Ananya R.",
    detail: "Mumbai · Heavyweight Combed Tee",
  },
  {
    quote:
      "I wore the Oxford Knitted Shirt for a three-day business trip. Crisp, breathable, and looks incredibly sharp.",
    name: "Kabir M.",
    detail: "Leh · Oxford Knitted Shirt",
  },
  {
    quote:
      "The loopback hoodie has amazing density and double-layer hood structure. Highest quality terry fleece.",
    name: "Elena S.",
    detail: "London · Heavy Loopback Hoodie",
  },
];

export default async function HomePage() {
  const [featured, newArrivals, collections, counts] = await Promise.all([
    getFeaturedProducts(8),
    getNewArrivals(4),
    listCollections(),
    getCatalogCounts(),
  ]);

  return (
    <div>
      {/* Hero */}
      <section className="relative">
        <div className="relative h-[78vh] min-h-[520px] w-full overflow-hidden">
          <Image
            src="/images/hero-main.jpg"
            alt="Tushar Hosiery fashion campaign - Charlie May collection"
            fill
            priority
            sizes="100vw"
            className="animate-fade object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-ink/10 to-ink/25" />
          <div className="absolute inset-0 flex flex-col justify-end px-4 pb-14 sm:px-8 sm:pb-20">
            <div className="mx-auto w-full max-w-[1600px]">
              <p className="label-xs animate-rise text-bone/80">Winter Weight · Chapter 09</p>
              <h1 className="display-xl mt-5 max-w-4xl text-bone">
                Knitted to be
                <br />
                worn out.
              </h1>
              <div className="mt-8 flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
                <p className="max-w-md text-sm leading-relaxed text-bone/85 sm:text-base">
                  Apparel knitted and tailored in Tiruppur. Heavyweight tees, oxford knits, selvedge denim & jackets,
                  engineered to outlast the season rather than define it.
                </p>
                <div className="flex flex-wrap items-center gap-3">
                  <Link
                    href="/shop"
                    className="label-sm bg-bone px-8 py-4 text-ink transition-colors hover:bg-henna hover:text-bone"
                  >
                    Shop the collection
                  </Link>
                  <Link
                    href="/collections/winter-weight"
                    className="label-sm border border-bone/60 px-8 py-4 text-bone transition-colors hover:bg-bone hover:text-ink"
                  >
                    Winter Weight
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-b border-ink/10 bg-bone">
          <div className="mx-auto grid max-w-[1600px] grid-cols-2 divide-ink/10 px-4 sm:px-8 lg:grid-cols-4 lg:divide-x">
            {promises.map((promise) => (
              <div key={promise.label} className="py-7 lg:px-8 lg:first:pl-0">
                <p className="label-xs text-henna">{promise.label}</p>
                <p className="mt-2 text-xs text-graphite">{promise.copy}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Categories Grid */}
      <FeaturedCategoriesGrid />

      {/* Categories */}
      <section className="mx-auto max-w-[1600px] px-4 py-20 sm:px-8 sm:py-28">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="label-xs text-stone">Shop by category</p>
            <h2 className="display-lg mt-4">Essential clothing collections</h2>
          </div>
          <Link href="/shop" className="label-sm link-underline text-graphite hover:text-ink">
            View all {counts.total > 0 ? counts.total : ""} pieces
          </Link>
        </div>

        <div className="mt-12 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {categoryTiles.map((tile, index) => (
            <Link
              key={tile.key}
              href={`/shop?category=${tile.key}`}
              className="group relative block aspect-[3/4] overflow-hidden bg-shell"
            >
              <Image
                src={tile.image}
                alt={CATEGORY_LABELS[tile.key] ?? tile.key}
                fill
                loading={index < 2 ? "eager" : "lazy"}
                sizes="(max-width: 640px) 50vw, 25vw"
                className="object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/75 via-ink/5 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-5">
                <h3 className="font-display text-2xl text-bone">{CATEGORY_LABELS[tile.key]}</h3>
                <p className="mt-2 text-[11px] leading-relaxed text-bone/75">{tile.copy}</p>
                <p className="label-xs mt-4 translate-y-1 text-bone opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                  Shop now →
                </p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured */}
      <section className="border-y border-ink/10 bg-shell/40">
        <div className="mx-auto max-w-[1600px] px-4 py-20 sm:px-8 sm:py-28">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="label-xs text-stone">Most worn</p>
              <h2 className="display-lg mt-4">The house favourites</h2>
            </div>
            <Link href="/shop?sort=rating" className="label-sm link-underline text-graphite hover:text-ink">
              Top rated
            </Link>
          </div>

          <div className="mt-12 grid grid-cols-2 gap-x-4 gap-y-12 lg:grid-cols-4">
            {featured.map((product, index) => (
              <ProductCard key={product.id} product={product} priority={index < 2} />
            ))}
          </div>
        </div>
      </section>

      {/* Mill story */}
      <section id="mill" className="mx-auto max-w-[1600px] px-4 py-20 sm:px-8 sm:py-28">
        <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
          <div className="relative aspect-[4/3] overflow-hidden bg-shell">
            <Image
              src="https://images.pexels.com/photos/9604298/pexels-photo-9604298.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"
              alt="Inside the Tushar Hosiery knitting mill"
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover"
            />
          </div>
          <div>
            <p className="label-xs text-henna">The mill · Tiruppur</p>
            <h2 className="display-lg mt-5">
              Forty-eight years on the same machines.
            </h2>
            <p className="mt-6 text-sm leading-relaxed text-graphite sm:text-base">
              Our grandfather bought the first circular frame in 1978, a single 84-needle machine
              that still runs twice a week. Today the floor holds thirty-one frames, none newer than
              1996, each one kept alive by a fitter who has been here longer than the machines.
            </p>
            <p className="mt-4 text-sm leading-relaxed text-graphite sm:text-base">
              Old frames knit slower. A Heavyweight Combed Tee takes longer to knit than mass production.
              The difference is density — a fabric that keeps its shape after the fiftieth wash.
            </p>
            <dl className="mt-10 grid grid-cols-3 gap-6 border-t border-ink/15 pt-8">
              {[
                { value: "1978", label: "Founded" },
                { value: "31", label: "Knitting frames" },
                { value: "260 GSM", label: "Min heavy weight" },
              ].map((stat) => (
                <div key={stat.label}>
                  <dt className="font-display text-3xl text-ink">{stat.value}</dt>
                  <dd className="label-xs mt-2 text-stone">{stat.label}</dd>
                </div>
              ))}
            </dl>
            <Link href="/about" className="label-sm mt-10 inline-block bg-ink px-8 py-4 text-bone hover:bg-henna">
              Inside the mill
            </Link>
          </div>
        </div>
      </section>

      {/* Campaign banner */}
      <section className="relative">
        <div className="relative h-[70vh] min-h-[440px] w-full overflow-hidden">
          <Image
            src="https://www.theundone.com/cdn/shop/articles/The-Undone_Charlie_May_Drop_Shoulder_Coat_LS_2.jpg?v=1474416186"
            alt="Winter Weight campaign"
            fill
            sizes="100vw"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-ink/35" />
          <div className="absolute inset-0 flex items-center">
            <div className="mx-auto w-full max-w-[1600px] px-4 sm:px-8">
              <p className="label-xs text-bone/80">Campaign 09 · Charlie May Edition</p>
              <h2 className="display-lg mt-5 max-w-xl text-bone">
                Built for the coldest weeks of the year.
              </h2>
              <Link
                href="/collections/winter-weight"
                className="label-sm mt-8 inline-block bg-bone px-8 py-4 text-ink transition-colors hover:bg-henna hover:text-bone"
              >
                Explore Winter Weight
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* New arrivals */}
      <section className="mx-auto max-w-[1600px] px-4 py-20 sm:px-8 sm:py-28">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="label-xs text-stone">Just landed</p>
            <h2 className="display-lg mt-4">New this month</h2>
          </div>
          <Link href="/shop?sort=new" className="label-sm link-underline text-graphite hover:text-ink">
            All new arrivals
          </Link>
        </div>
        <div className="mt-12 grid grid-cols-2 gap-x-4 gap-y-12 lg:grid-cols-4">
          {newArrivals.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Collections */}
      <section className="border-y border-ink/10 bg-shell/40 text-ink">
        <div className="mx-auto max-w-[1600px] px-4 py-20 sm:px-8 sm:py-28">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="label-xs text-stone">Five groups, craft focus</p>
              <h2 className="display-lg mt-4 text-ink">Collections</h2>
            </div>
            <p className="max-w-sm text-xs leading-relaxed text-graphite">
              Every piece we make belongs to one of five groups, each defined by fabric weight, gauge and intended wear.
            </p>
          </div>

          <div className="mt-12 grid gap-px bg-ink/10 sm:grid-cols-2 lg:grid-cols-3">
            {collections.map((collection) => (
              <Link
                key={collection.id}
                href={`/collections/${collection.slug}`}
                className="group relative flex min-h-[260px] flex-col justify-between bg-white p-8 transition-colors hover:bg-bone"
              >
                <div>
                  <p className="label-xs text-stone">{collection.kicker}</p>
                  <h3 className="display-md mt-3 text-ink">{collection.title}</h3>
                  <p className="mt-4 max-w-sm text-xs leading-relaxed text-graphite">
                    {collection.description}
                  </p>
                </div>
                <span className="label-xs mt-8 text-ink font-medium transition-transform duration-500 group-hover:translate-x-1">
                  View collection →
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="mx-auto max-w-[1600px] px-4 py-20 sm:px-8 sm:py-28">
        <p className="label-xs text-stone">Worn in</p>
        <h2 className="display-lg mt-4">From the people wearing them</h2>
        <div className="mt-12 grid gap-8 lg:grid-cols-3">
          {testimonials.map((testimonial) => (
            <figure key={testimonial.name} className="border-t border-ink/15 pt-6">
              <blockquote className="font-display text-xl leading-snug text-ink">
                “{testimonial.quote}”
              </blockquote>
              <figcaption className="mt-6">
                <p className="label-xs text-graphite">{testimonial.name}</p>
                <p className="mt-1 text-[11px] text-stone">{testimonial.detail}</p>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* Newsletter */}
      <section className="border-t border-ink/10 bg-shell/50">
        <div className="mx-auto grid max-w-[1600px] gap-10 px-4 py-20 sm:px-8 lg:grid-cols-2 lg:items-center">
          <div>
            <p className="label-xs text-henna">First access</p>
            <h2 className="display-lg mt-4">Restocks sell out in hours.</h2>
            <p className="mt-5 max-w-md text-sm leading-relaxed text-graphite">
              We knit in batches of three hundred. Join the list to be told before the site is.
            </p>
          </div>
          <div className="max-w-lg">
            <NewsletterForm />
            <p className="mt-6 text-[11px] text-stone">
              One email a fortnight. Nothing else, ever.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
