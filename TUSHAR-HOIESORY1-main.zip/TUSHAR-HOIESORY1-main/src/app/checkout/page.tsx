import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import CheckoutForm from "@/components/checkout-form";
import { getCartSummary } from "@/lib/cart";
import { formatPrice, freeShippingThreshold } from "@/lib/format";

export const metadata: Metadata = { title: "Checkout" };

export default async function CheckoutPage() {
  const cart = await getCartSummary();
  const freeShippingUnlocked = cart.subtotalCents >= freeShippingThreshold();

  return (
    <div className="mx-auto max-w-[1600px] px-4 py-14 sm:px-8 sm:py-20">
      <nav className="label-xs flex items-center gap-2 text-stone">
        <Link href="/cart" className="hover:text-ink">Bag</Link>
        <span>/</span>
        <span className="text-graphite">Checkout</span>
      </nav>

      <div className="mt-6 flex flex-wrap items-end justify-between gap-6">
        <h1 className="display-lg">Checkout</h1>
        <Link href="/cart" className="label-xs text-henna link-underline">
          ← Back to bag
        </Link>
      </div>

      {cart.lines.length === 0 ? (
        <div className="mt-12 border border-dashed border-ink/20 px-6 py-24 text-center">
          <p className="display-md">There is nothing to check out.</p>
          <Link
            href="/shop"
            className="label-sm mt-8 inline-block bg-ink px-8 py-4 text-bone hover:bg-henna"
          >
            Shop the collection
          </Link>
        </div>
      ) : (
        <div className="mt-4 grid gap-16 lg:grid-cols-[1.4fr_1fr]">
          <CheckoutForm
            subtotalCents={cart.subtotalCents}
            freeShippingUnlocked={freeShippingUnlocked}
          />

          <aside className="lg:sticky lg:top-[168px] lg:self-start">
            <div className="border border-ink/15 p-7">
              <p className="label-xs text-stone">In your bag</p>
              <ul className="mt-6 divide-y divide-ink/10">
                {cart.lines.map((line) => (
                  <li key={line.itemId} className="flex gap-4 py-4">
                    <div className="relative h-24 w-18 shrink-0 overflow-hidden bg-shell">
                      <Image
                        src={line.product.images[0]}
                        alt={line.product.name}
                        fill
                        sizes="100px"
                        className="object-cover"
                      />
                    </div>
                    <div className="flex flex-1 flex-col">
                      <p className="text-xs font-medium">{line.product.name}</p>
                      <p className="mt-1 text-[11px] text-stone">
                        Size {line.size} · Qty {line.quantity}
                      </p>
                    </div>
                    <p className="text-xs">{formatPrice(line.lineTotalCents)}</p>
                  </li>
                ))}
              </ul>

              <div className="mt-4 space-y-3 border-t border-ink/15 pt-5 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-graphite">Subtotal</span>
                  <span>{formatPrice(cart.subtotalCents)}</span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-stone">
                  <span>Shipping</span>
                  <span>Calculated at the final step</span>
                </div>
              </div>
            </div>

            <div className="mt-6 border border-ink/15 p-7">
              <p className="label-xs text-stone">Why buy direct</p>
              <ul className="mt-5 space-y-3">
                {[
                  "Knitted, dyed and finished in one mill",
                  "No middlemen — one price, all year",
                  "Free repairs on seams for two years",
                ].map((item) => (
                  <li key={item} className="flex gap-3 text-[11px] leading-relaxed text-graphite">
                    <span className="text-henna">—</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
