import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import AddToCartForm from "@/components/add-to-cart-form";
import ProductCard from "@/components/product-card";
import { AUDIENCE_LABELS, CATEGORY_LABELS, getProductBySlug, getRelatedProducts, listCollections } from "@/lib/catalog";
import { formatPrice, ratingToStars } from "@/lib/format";

type Params = { slug: string };

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return { title: "Piece not found" };
  return {
    title: product.name,
    description: `${product.tagline} — ${product.description.slice(0, 140)}`,
    openGraph: {
      title: `${product.name} · Tushar Hosiery`,
      images: product.images.slice(0, 1),
    },
  };
}

export default async function ProductPage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const [related, collections] = await Promise.all([
    getRelatedProducts(product, 4),
    listCollections(),
  ]);

  const collection = collections.find((item) => item.slug === product.collectionSlug);
  const [primary, ...gallery] = product.images;

  return (
    <div>
      <div className="mx-auto max-w-[1600px] px-4 pt-10 sm:px-8 sm:pt-16">
        <nav className="label-xs flex flex-wrap items-center gap-2 text-stone">
          <Link href="/" className="hover:text-ink">Home</Link>
          <span>/</span>
          <Link href={`/shop?category=${product.category}`} className="hover:text-ink">
            {CATEGORY_LABELS[product.category] ?? "Shop"}
          </Link>
          <span>/</span>
          <span className="text-graphite">{product.name}</span>
        </nav>
      </div>

      <section className="mx-auto grid max-w-[1600px] gap-10 px-4 py-10 sm:px-8 lg:grid-cols-[1.25fr_1fr] lg:gap-16 lg:py-16">
        <div className="flex flex-col gap-4">
          <div className="relative aspect-[4/5] w-full overflow-hidden bg-shell">
            <Image
              src={primary}
              alt={product.name}
              fill
              priority
              sizes="(max-width: 1024px) 100vw, 60vw"
              className="object-cover"
            />
          </div>
          {gallery.map((image, index) => (
            <div key={`${image}-${index}`} className="relative aspect-[4/5] w-full overflow-hidden bg-shell">
              <Image
                src={image}
                alt={`${product.name} view ${index + 2}`}
                fill
                sizes="(max-width: 1024px) 100vw, 60vw"
                className="object-cover"
              />
            </div>
          ))}
        </div>

        <div className="lg:sticky lg:top-[168px] lg:self-start">
          <div className="flex items-center gap-3">
            {collection && (
              <Link
                href={`/collections/${collection.slug}`}
                className="label-xs text-henna link-underline"
              >
                {collection.title}
              </Link>
            )}
            <span className="label-xs text-stone">
              {CATEGORY_LABELS[product.category]} · {AUDIENCE_LABELS[product.audience]}
            </span>
          </div>

          <h1 className="display-lg mt-5">{product.name}</h1>
          <p className="mt-3 text-sm text-stone">{product.tagline}</p>

          <div className="mt-6 flex items-center gap-4">
            <p className="font-display text-3xl">{formatPrice(product.priceCents)}</p>
            {product.compareAtCents && product.compareAtCents > product.priceCents && (
              <p className="text-sm text-stone line-through">{formatPrice(product.compareAtCents)}</p>
            )}
            <span className="label-xs text-stone">
              {ratingToStars(product.rating)} {(product.rating / 10).toFixed(1)} ({product.reviewCount})
            </span>
          </div>

          <p className="mt-8 text-sm leading-relaxed text-graphite">{product.description}</p>

          <div className="mt-8 flex flex-wrap items-center gap-4 border-t border-ink/15 pt-6">
            <span
              aria-hidden
              className="h-6 w-6 rounded-full border border-ink/20"
              style={{ backgroundColor: product.colorHex }}
            />
            <span className="text-xs text-graphite">{product.colorName}</span>
            {product.denier && (
              <>
                <span className="text-xs text-stone/60">·</span>
                <span className="label-xs text-stone">{product.denier}</span>
              </>
            )}
          </div>

          <AddToCartForm
            slug={product.slug}
            name={product.name}
            priceCents={product.priceCents}
            sizes={product.sizes}
          />

          <div className="mt-12 divide-y divide-ink/10 border-t border-ink/15">
            <details open className="group py-5">
              <summary className="label-sm flex cursor-pointer items-center justify-between text-ink">
                Fabric & construction
                <span className="text-stone transition-transform group-open:rotate-45">+</span>
              </summary>
              <p className="mt-4 text-xs leading-relaxed text-graphite">{product.fabric}</p>
            </details>

            <details className="group py-5">
              <summary className="label-sm flex cursor-pointer items-center justify-between text-ink">
                Detailing
                <span className="text-stone transition-transform group-open:rotate-45">+</span>
              </summary>
              <ul className="mt-4 space-y-2">
                {product.details.map((detail) => (
                  <li key={detail} className="flex gap-3 text-xs leading-relaxed text-graphite">
                    <span className="text-henna">—</span>
                    {detail}
                  </li>
                ))}
              </ul>
            </details>

            <details className="group py-5">
              <summary className="label-sm flex cursor-pointer items-center justify-between text-ink">
                Shipping & returns
                <span className="text-stone transition-transform group-open:rotate-45">+</span>
              </summary>
              <p className="mt-4 text-xs leading-relaxed text-graphite">
                Dispatched from Tiruppur within 24 hours. Free shipping on orders above ₹3,000,
                otherwise ₹99. Express delivery in 2–3 days at ₹249. Returns accepted within 30
                days, worn or unworn.
              </p>
            </details>

            <details className="group py-5">
              <summary className="label-sm flex cursor-pointer items-center justify-between text-ink">
                The mill
                <span className="text-stone transition-transform group-open:rotate-45">+</span>
              </summary>
              <p className="mt-4 text-xs leading-relaxed text-graphite">
                Knitted in Tiruppur, Tamil Nadu on a {product.category === "tights" ? "single-needle" : "circular"} frame
                finished by hand. Read more about{" "}
                <Link href="/about" className="text-henna link-underline">
                  how we work
                </Link>
                .
              </p>
            </details>
          </div>
        </div>
      </section>

      {related.length > 0 && (
        <section className="border-t border-ink/10 bg-shell/40">
          <div className="mx-auto max-w-[1600px] px-4 py-20 sm:px-8">
            <div className="flex flex-wrap items-end justify-between gap-6">
              <div>
                <p className="label-xs text-stone">From the same group</p>
                <h2 className="display-lg mt-4">Wears well with</h2>
              </div>
              <Link
                href={`/collections/${product.collectionSlug}`}
                className="label-sm link-underline text-graphite hover:text-ink"
              >
                View {collection?.title ?? "collection"}
              </Link>
            </div>
            <div className="mt-12 grid grid-cols-2 gap-x-4 gap-y-12 lg:grid-cols-4">
              {related.map((item) => (
                <ProductCard key={item.id} product={item} />
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
