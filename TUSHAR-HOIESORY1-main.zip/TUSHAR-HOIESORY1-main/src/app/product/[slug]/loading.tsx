export default function ProductLoading() {
  return (
    <div className="mx-auto grid max-w-[1600px] gap-10 px-4 py-16 sm:px-8 lg:grid-cols-[1.25fr_1fr] lg:gap-16">
      <div className="flex flex-col gap-4">
        <div className="aspect-[4/5] w-full animate-pulse bg-shell" />
        <div className="aspect-[4/5] w-full animate-pulse bg-shell" />
      </div>
      <div className="space-y-6">
        <div className="h-3 w-32 bg-ink/10" />
        <div className="h-10 w-3/4 bg-ink/10" />
        <div className="h-3 w-1/2 bg-ink/10" />
        <div className="h-8 w-28 bg-ink/10" />
        <div className="space-y-3 pt-4">
          <div className="h-3 w-full bg-ink/10" />
          <div className="h-3 w-11/12 bg-ink/10" />
          <div className="h-3 w-9/12 bg-ink/10" />
        </div>
        <div className="mt-10 grid grid-cols-4 gap-2">
          {Array.from({ length: 4 }).map((_, index) => (
            <div key={index} className="h-12 bg-ink/10" />
          ))}
        </div>
        <div className="h-16 w-full bg-ink/10" />
      </div>
    </div>
  );
}
