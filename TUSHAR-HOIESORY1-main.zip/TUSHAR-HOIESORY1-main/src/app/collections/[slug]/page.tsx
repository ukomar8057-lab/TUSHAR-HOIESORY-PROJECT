import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import ProductCard from "@/components/product-card";
import { getCollectionBySlug, listCollections, listProducts } from "@/lib/catalog";

type Params = { slug: string };

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const collection = await getCollectionBySlug(slug);
  if (!collection) return { title: "Collection not found" };
  return { title: collection.title, description: collection.description };
}

export default async function CollectionPage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const collection = await getCollectionBySlug(slug);
  if (!collection) notFound();

  const [products, collections] = await Promise.all([
    listProducts({ collection: slug }),
    listCollections(),
  ]);

  const others = collections.filter((item) => item.slug !== slug);

  return (
    <div>
      <section className="relative">
        <div className="relative h-[58vh] min-h-[400px] w-full overflow-hidden">
          <Image
            src={collection.image}
            alt={collection.title}
            fill
            priority
            sizes="100vw"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/25 to-ink/10" />
          <div className="absolute inset-0 flex flex-col justify-end px-4 pb-14 sm:px-8">
            <div className="mx-auto w-full max-w-[1600px]">
              <p className="label-xs text-bone/75">{collection.kicker}</p>
              <h1 className="display-xl mt-4 text-bone">{collection.title}</h1>
              <p className="mt-6 max-w-xl text-sm leading-relaxed text-bone/85">
                {collection.description}
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="border-b border-ink/10">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center gap-x-8 gap-y-3 px-4 py-5 sm:px-8">
          <span className="label-xs text-stone">
            {products.length} {products.length === 1 ? "piece" : "pieces"}
          </span>
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
            {others.map((item) => (
              <Link
                key={item.slug}
                href={`/collections/${item.slug}`}
                className="label-xs link-underline text-graphite hover:text-ink"
              >
                {item.title}
              </Link>
            ))}
          </div>
          <Link href="/shop" className="label-xs ml-auto text-henna link-underline">
            Shop everything →
          </Link>
        </div>
      </section>

      <section className="mx-auto max-w-[1600px] px-4 py-16 sm:px-8 sm:py-20">
        {products.length === 0 ? (
          <p className="border border-dashed border-ink/20 px-6 py-20 text-center text-sm text-graphite">
            This group is being restocked. Check back shortly.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-x-4 gap-y-14 md:grid-cols-3 lg:grid-cols-4">
            {products.map((product, index) => (
              <ProductCard key={product.id} product={product} priority={index < 4} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
