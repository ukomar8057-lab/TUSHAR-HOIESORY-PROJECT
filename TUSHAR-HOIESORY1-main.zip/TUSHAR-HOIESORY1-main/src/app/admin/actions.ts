"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { asc, count, eq, ilike, min, sql } from "drizzle-orm";
import { db } from "@/db";
import { collections, orderItems, orders, products } from "@/db/schema";
import { getAdminUser, hasAdminRole } from "@/lib/admin-auth";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { getSupabaseEnv } from "@/lib/supabase/env";
import { AUDIENCE_LABELS, CATEGORY_LABELS } from "@/lib/constants";
import { allowedImageHosts, isAllowedImageUrl } from "@/lib/image-hosts";
import { hasFile, uploadProductImage } from "@/lib/product-images";

const ORDER_STATUSES = ["confirmed", "processing", "shipped", "delivered", "cancelled"];

/* ------------------------------------------------------------------ */
/* Login / logout / session                                            */
/* ------------------------------------------------------------------ */

export async function loginAdminAction(
  formData: FormData,
): Promise<{ ok: boolean; error?: string }> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");

  if (!getSupabaseEnv()) {
    return {
      ok: false,
      error:
        "Supabase is not configured yet. Add NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY to .env.local and restart.",
    };
  }
  if (!email || !password) return { ok: false, error: "Enter your email and password." };

  try {
    const supabase = await createSupabaseServerClient();
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error || !data.user) {
      const message = /confirm/i.test(error?.message ?? "")
        ? "This email is not confirmed yet. In Supabase, open Authentication > Users and confirm it."
        : "Invalid email or password.";
      return { ok: false, error: message };
    }

    let isAdmin = false;
    try {
      isAdmin = await hasAdminRole(data.user.id);
    } catch (dbError) {
      console.error("[admin-login] database check failed:", dbError);
      await supabase.auth.signOut();
      return {
        ok: false,
        error:
          "Signed in, but the website cannot reach the database. Check DATABASE_URL in .env.local and that the setup SQL was run.",
      };
    }

    if (!isAdmin) {
      await supabase.auth.signOut();
      return {
        ok: false,
        error: "This account is not an admin. Use the admin email that was set in the setup SQL.",
      };
    }
    return { ok: true };
  } catch (error) {
    console.error("[admin-login] failed:", error);
    return { ok: false, error: "Login failed because of a server error. Check the server logs." };
  }
}

export async function logoutAdminAction() {
  try {
    const supabase = await createSupabaseServerClient();
    await supabase.auth.signOut();
  } catch (error) {
    console.error("[admin-logout] failed:", error);
  }
  redirect("/admin/login");
}

export async function verifyAdminSession(): Promise<boolean> {
  return Boolean(await getAdminUser());
}

export async function requireAdminSession() {
  if (!(await getAdminUser())) {
    redirect("/admin/login");
  }
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function refreshStorefront() {
  revalidatePath("/", "layout");
}

/** Sends the admin back to a form with a readable error message. */
function failTo(path: string, message: string): never {
  redirect(`${path}?error=${encodeURIComponent(message)}`);
}

function slugify(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 60);
}

async function uniqueSlug(
  table: typeof products | typeof collections,
  base: string,
): Promise<string> {
  const root = base || "item";
  const existing = await db
    .select({ slug: table.slug })
    .from(table)
    .where(ilike(table.slug, `${root}%`));
  const taken = new Set(existing.map((row) => row.slug));
  if (!taken.has(root)) return root;
  for (let i = 2; i < 500; i++) {
    if (!taken.has(`${root}-${i}`)) return `${root}-${i}`;
  }
  return `${root}-${Date.now()}`;
}

/** Resolves an image from an uploaded file or a pasted URL. Returns null when neither is given. */
async function resolveImage(
  formData: FormData,
  fileField: string,
  urlField: string,
): Promise<string | null> {
  const file = formData.get(fileField);
  if (hasFile(file)) return uploadProductImage(file);

  const url = String(formData.get(urlField) ?? "").trim();
  if (!url) return null;
  if (!isAllowedImageUrl(url)) {
    throw new Error(
      `That image link is not allowed. Upload the image file instead, or use a link from: ${allowedImageHosts().join(", ")}.`,
    );
  }
  return url;
}

function splitList(value: string, fallback: string): string[] {
  const list = (value || fallback)
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
  return list.length > 0 ? list : fallback.split(",").map((item) => item.trim());
}

type ProductInput = {
  name: string;
  tagline: string;
  description: string;
  category: string;
  audience: string;
  collectionSlug: string;
  priceCents: number;
  colorName: string;
  colorHex: string;
  fabric: string;
  stock: number;
  badge: string | null;
  isFeatured: boolean;
  isNew: boolean;
  sizes: string[];
  details: string[];
};

/** Reads + validates the product form. Throws Error(message) for anything wrong. */
async function parseProductForm(formData: FormData): Promise<ProductInput> {
  const text = (key: string) => String(formData.get(key) ?? "").trim();

  const name = text("name");
  const tagline = text("tagline");
  const description = text("description");
  const category = text("category");
  const audience = text("audience");
  const collectionSlug = text("collectionSlug");
  const colorName = text("colorName");
  const fabric = text("fabric");
  const colorHexRaw = text("colorHex") || "#141414";
  const price = Number(text("price"));
  const stock = Number(text("stock") || "0");

  if (name.length < 2) throw new Error("Product name is required.");
  if (!tagline) throw new Error("Tagline is required.");
  if (!description) throw new Error("Description is required.");
  if (!CATEGORY_LABELS[category]) throw new Error("Choose a valid category.");
  if (!AUDIENCE_LABELS[audience]) throw new Error("Choose a valid audience.");
  if (!collectionSlug) throw new Error("Choose a collection.");
  if (!colorName) throw new Error("Color name is required.");
  if (!fabric) throw new Error("Fabric composition is required.");
  if (!Number.isFinite(price) || price <= 0) throw new Error("Price must be greater than 0.");
  if (!Number.isInteger(stock) || stock < 0) throw new Error("Stock must be a whole number, 0 or more.");
  if (!/^#[0-9a-fA-F]{6}$/.test(colorHexRaw)) {
    throw new Error("Color hex must look like #F2EFE9.");
  }

  const collection = await db
    .select({ id: collections.id })
    .from(collections)
    .where(eq(collections.slug, collectionSlug))
    .limit(1);
  if (!collection[0]) throw new Error("That collection does not exist.");

  return {
    name,
    tagline,
    description,
    category,
    audience,
    collectionSlug,
    priceCents: Math.round(price * 100),
    colorName,
    colorHex: colorHexRaw,
    fabric,
    stock,
    badge: text("badge") || null,
    isFeatured: formData.get("isFeatured") === "on",
    isNew: formData.get("isNew") === "on",
    sizes: splitList(text("sizes"), "S, M, L, XL"),
    details: splitList(text("details"), "Combed cotton, Wash cold"),
  };
}

function messageOf(error: unknown, fallback: string): string {
  return error instanceof Error && error.message ? error.message : fallback;
}

/* ------------------------------------------------------------------ */
/* Products                                                            */
/* ------------------------------------------------------------------ */

export async function createProductAction(formData: FormData): Promise<void> {
  await requireAdminSession();
  const back = "/admin/products/new";

  try {
    const input = await parseProductForm(formData);

    const image1 = await resolveImage(formData, "image1File", "image1");
    if (!image1) throw new Error("Main image is required. Upload a file or paste an image link.");
    const image2 = await resolveImage(formData, "image2File", "image2");
    const images = image2 ? [image1, image2] : [image1];

    const slug = await uniqueSlug(products, slugify(input.name));
    const top = await db.select({ lowest: min(products.sortOrder) }).from(products);
    const sortOrder = (top[0]?.lowest ?? 1) - 1; // shows first in the shop

    await db.insert(products).values({
      ...input,
      slug,
      images,
      compareAtCents: null,
      denier: null,
      rating: 49,
      reviewCount: 1,
      sortOrder,
    });
  } catch (error) {
    console.error("[admin] create product failed:", error);
    failTo(back, messageOf(error, "Could not create the product."));
  }

  refreshStorefront();
  redirect("/admin/products");
}

export async function updateProductAction(id: number, formData: FormData): Promise<void> {
  await requireAdminSession();
  const back = `/admin/products/${id}/edit`;

  try {
    const existing = await db.select().from(products).where(eq(products.id, id)).limit(1);
    if (!existing[0]) throw new Error("This product no longer exists.");

    const input = await parseProductForm(formData);

    const image1 = (await resolveImage(formData, "image1File", "image1")) ?? existing[0].images[0];
    if (!image1) throw new Error("Main image is required. Upload a file or paste an image link.");
    const image2 = await resolveImage(formData, "image2File", "image2");
    const images = image2 ? [image1, image2] : [image1];

    await db.update(products).set({ ...input, images }).where(eq(products.id, id));
  } catch (error) {
    console.error("[admin] update product failed:", error);
    failTo(back, messageOf(error, "Could not update the product."));
  }

  refreshStorefront();
  redirect("/admin/products");
}

export async function deleteProductAction(id: number): Promise<void> {
  await requireAdminSession();
  await db.delete(products).where(eq(products.id, id));
  refreshStorefront();
  revalidatePath("/admin/products");
}

/* ------------------------------------------------------------------ */
/* Collections                                                         */
/* ------------------------------------------------------------------ */

export async function createCollectionAction(formData: FormData): Promise<void> {
  await requireAdminSession();
  const back = "/admin/collections";

  try {
    const title = String(formData.get("title") ?? "").trim();
    const kicker = String(formData.get("kicker") ?? "").trim();
    const description = String(formData.get("description") ?? "").trim();
    if (title.length < 2) throw new Error("Collection title is required.");
    if (!kicker) throw new Error("Kicker tag is required.");
    if (!description) throw new Error("Description is required.");

    const image = await resolveImage(formData, "imageFile", "image");
    if (!image) throw new Error("Banner image is required. Upload a file or paste an image link.");

    const slug = await uniqueSlug(collections, slugify(title));
    const top = await db.select({ highest: count() }).from(collections);

    await db.insert(collections).values({
      slug,
      title,
      kicker,
      description,
      image,
      sortOrder: (top[0]?.highest ?? 0) + 1,
    });
  } catch (error) {
    console.error("[admin] create collection failed:", error);
    failTo(back, messageOf(error, "Could not create the collection."));
  }

  refreshStorefront();
  redirect("/admin/collections");
}

export async function deleteCollectionAction(id: number): Promise<void> {
  await requireAdminSession();

  const rows = await db.select().from(collections).where(eq(collections.id, id)).limit(1);
  const collection = rows[0];
  if (!collection) {
    redirect("/admin/collections");
  }

  const inUse = await db
    .select({ id: products.id })
    .from(products)
    .where(eq(products.collectionSlug, collection.slug))
    .orderBy(asc(products.id))
    .limit(1);
  if (inUse[0]) {
    failTo(
      "/admin/collections",
      `"${collection.title}" still has products. Move or delete those products first.`,
    );
  }

  await db.delete(collections).where(eq(collections.id, id));
  refreshStorefront();
  redirect("/admin/collections");
}

/* ------------------------------------------------------------------ */
/* Orders                                                              */
/* ------------------------------------------------------------------ */

export async function updateOrderStatusAction(orderId: number, status: string): Promise<void> {
  await requireAdminSession();

  if (!ORDER_STATUSES.includes(status)) {
    failTo("/admin/orders", "Invalid order status.");
  }

  const found = await db.transaction(async (tx) => {
    // Lock the order row so double-clicks cannot restock twice.
    const locked = await tx.execute(
      sql`SELECT status FROM orders WHERE id = ${orderId} FOR UPDATE`,
    );
    const row = locked.rows[0] as { status: string } | undefined;
    if (!row) return false;

    const wasCancelled = row.status === "cancelled";
    const nowCancelled = status === "cancelled";

    if (wasCancelled !== nowCancelled) {
      const items = await tx.select().from(orderItems).where(eq(orderItems.orderId, orderId));
      for (const item of items) {
        await tx
          .update(products)
          .set({
            // cancelled -> give stock back; re-opened -> take it again (never below 0)
            stock: nowCancelled
              ? sql`${products.stock} + ${item.quantity}`
              : sql`GREATEST(${products.stock} - ${item.quantity}, 0)`,
          })
          .where(eq(products.id, item.productId));
      }
    }

    await tx.update(orders).set({ status }).where(eq(orders.id, orderId));
    return true;
  });

  if (!found) {
    failTo("/admin/orders", "That order no longer exists.");
  }

  refreshStorefront();
  revalidatePath("/admin/orders");
  revalidatePath("/admin");
}
