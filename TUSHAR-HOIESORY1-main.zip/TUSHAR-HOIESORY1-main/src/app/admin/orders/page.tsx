import { requireAdminSession, updateOrderStatusAction } from "../actions";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { formatPhone } from "@/lib/phone";
import { desc } from "drizzle-orm";

export default async function AdminOrdersPage() {
  await requireAdminSession();

  const orderList = await db.select().from(orders).orderBy(desc(orders.createdAt));

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold text-ink">Orders Management</h1>
        <p className="text-xs text-graphite mt-1">
          Track customer purchases, shipping details, and update fulfillment status.
        </p>
      </div>

      <div className="rounded-2xl border border-ink/10 bg-white p-6 shadow-sm">
        {orderList.length === 0 ? (
          <div className="py-12 text-center">
            <p className="text-sm font-medium text-graphite">No orders found yet.</p>
            <p className="text-xs text-stone mt-1">New customer checkout orders will appear here automatically.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-ink/10 text-stone">
                  <th className="pb-3 font-medium">Order #</th>
                  <th className="pb-3 font-medium">Customer</th>
                  <th className="pb-3 font-medium">Mobile</th>
                  <th className="pb-3 font-medium">Shipping Address</th>
                  <th className="pb-3 font-medium">Total</th>
                  <th className="pb-3 font-medium">Status</th>
                  <th className="pb-3 font-medium text-right">Update Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink/10">
                {orderList.map((order) => (
                  <tr key={order.id} className="hover:bg-bone/40">
                    <td className="py-4 font-mono font-bold text-ink text-sm">#{order.orderNumber}</td>
                    <td className="py-4">
                      <p className="font-bold text-ink">{order.fullName}</p>
                      <p className="text-stone text-[11px]">{order.email}</p>
                    </td>
                    <td className="py-4 whitespace-nowrap">
                      {order.phone ? (
                        <a
                          href={`tel:${order.phone}`}
                          className="font-medium text-ink hover:text-henna"
                        >
                          {formatPhone(order.phone)}
                        </a>
                      ) : (
                        <span className="text-stone">-</span>
                      )}
                    </td>
                    <td className="py-4 text-graphite max-w-xs truncate">
                      {order.address}, {order.city}
                    </td>
                    <td className="py-4 font-bold text-ink text-sm">
                      ₹{(order.totalCents / 100).toLocaleString("en-IN")}
                    </td>
                    <td className="py-4">
                      <span
                        className={`label-xs rounded px-2.5 py-1 font-semibold uppercase ${
                          order.status === "delivered"
                            ? "bg-moss/15 text-moss"
                            : order.status === "shipped"
                            ? "bg-blue-100 text-blue-800"
                            : order.status === "cancelled"
                            ? "bg-henna/15 text-henna"
                            : "bg-amber-100 text-amber-800"
                        }`}
                      >
                        {order.status}
                      </span>
                    </td>
                    <td className="py-4 text-right">
                      <form
                        action={async (formData: FormData) => {
                          "use server";
                          const newStatus = formData.get("status") as string;
                          await updateOrderStatusAction(order.id, newStatus);
                        }}
                        className="inline-flex items-center gap-2"
                      >
                        <select
                          name="status"
                          defaultValue={order.status}
                          className="rounded border border-ink/20 bg-white px-2 py-1 text-xs text-ink outline-none focus:border-ink"
                        >
                          <option value="confirmed">Confirmed</option>
                          <option value="processing">Processing</option>
                          <option value="shipped">Shipped</option>
                          <option value="delivered">Delivered</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                        <button
                          type="submit"
                          className="label-xs rounded bg-ink px-3 py-1 text-bone hover:bg-henna"
                        >
                          Save
                        </button>
                      </form>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
