/** Red message box shown on admin forms when a save fails (same look as the login error). */
export function ErrorBanner({ message }: { message?: string }) {
  if (!message) return null;
  return (
    <p
      role="alert"
      className="text-xs text-henna bg-henna/10 p-3 rounded border border-henna/30"
    >
      {message}
    </p>
  );
}
