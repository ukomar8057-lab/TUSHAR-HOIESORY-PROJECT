import Link from "next/link";
import { requireAdminSession, createProductAction } from "../../actions";
import { CATEGORY_LABELS, AUDIENCE_LABELS } from "@/lib/constants";
import { listCollections } from "@/lib/catalog";
import { ErrorBanner } from "../../error-banner";

export default async function NewProductPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  await requireAdminSession();
  const collectionList = await listCollections();
  const { error } = await searchParams;

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-ink">Add New Product</h1>
          <p className="text-xs text-graphite mt-1">
            Fill in the details below to publish a new clothing item to the store catalog.
          </p>
        </div>
        <Link
          href="/admin/products"
          className="label-xs border border-ink/20 px-4 py-2 text-ink transition-colors hover:bg-ink hover:text-bone rounded"
        >
          ← Back to Products
        </Link>
      </div>

      <ErrorBanner message={error} />

      <form action={createProductAction} className="rounded-2xl border border-ink/10 bg-white p-8 shadow-sm space-y-6">
        <div className="grid gap-6 sm:grid-cols-2">
          <div>
            <label className="label-xs block text-stone mb-2">Product Name *</label>
            <input
              type="text"
              name="name"
              required
              placeholder="e.g. Heavyweight Combed Cotton Tee"
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
            />
          </div>

          <div>
            <label className="label-xs block text-stone mb-2">Tagline *</label>
            <input
              type="text"
              name="tagline"
              required
              placeholder="e.g. 260 GSM single jersey cotton"
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
            />
          </div>
        </div>

        <div>
          <label className="label-xs block text-stone mb-2">Full Description *</label>
          <textarea
            name="description"
            required
            rows={4}
            placeholder="Detailed description of the garment, fit, yarn density, and craftsmanship details..."
            className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
          />
        </div>

        <div className="grid gap-6 sm:grid-cols-3">
          <div>
            <label className="label-xs block text-stone mb-2">Category *</label>
            <select
              name="category"
              required
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink bg-white"
            >
              {Object.entries(CATEGORY_LABELS).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="label-xs block text-stone mb-2">Target Audience *</label>
            <select
              name="audience"
              required
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink bg-white"
            >
              {Object.entries(AUDIENCE_LABELS).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="label-xs block text-stone mb-2">Collection *</label>
            <select
              name="collectionSlug"
              required
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink bg-white"
            >
              {collectionList.map((c) => (
                <option key={c.slug} value={c.slug}>
                  {c.title}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid gap-6 sm:grid-cols-3">
          <div>
            <label className="label-xs block text-stone mb-2">Price (INR ₹) *</label>
            <input
              type="number"
              step="1"
              name="price"
              required
              placeholder="e.g. 1499"
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
            />
          </div>

          <div>
            <label className="label-xs block text-stone mb-2">Stock Quantity *</label>
            <input
              type="number"
              name="stock"
              required
              defaultValue={40}
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
            />
          </div>

          <div>
            <label className="label-xs block text-stone mb-2">Badge Tag (Optional)</label>
            <input
              type="text"
              name="badge"
              placeholder="e.g. Bestseller, New, Organic"
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
            />
          </div>
        </div>

        <div className="grid gap-6 sm:grid-cols-3">
          <div>
            <label className="label-xs block text-stone mb-2">Color Name *</label>
            <input
              type="text"
              name="colorName"
              required
              placeholder="e.g. Bone White"
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
            />
          </div>

          <div>
            <label className="label-xs block text-stone mb-2">Color Hex Code</label>
            <input
              type="text"
              name="colorHex"
              defaultValue="#F2EFE9"
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
            />
          </div>

          <div>
            <label className="label-xs block text-stone mb-2">Fabric Composition *</label>
            <input
              type="text"
              name="fabric"
              required
              placeholder="e.g. 100% combed cotton, 260 GSM"
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
            />
          </div>
        </div>

        <div className="grid gap-6 sm:grid-cols-2">
          <div className="space-y-2">
            <label className="label-xs block text-stone mb-2">Main Image *</label>
            <input
              type="file"
              name="image1File"
              accept="image/jpeg,image/png,image/webp,image/gif,image/avif"
              className="w-full text-xs text-graphite file:mr-3 file:rounded file:border-0 file:bg-ink file:px-3 file:py-2 file:text-xs file:text-bone hover:file:bg-henna"
            />
            <input
              type="url"
              name="image1"
              placeholder="…or paste an image link (https://...)"
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
            />
          </div>

          <div className="space-y-2">
            <label className="label-xs block text-stone mb-2">Secondary Image (Optional)</label>
            <input
              type="file"
              name="image2File"
              accept="image/jpeg,image/png,image/webp,image/gif,image/avif"
              className="w-full text-xs text-graphite file:mr-3 file:rounded file:border-0 file:bg-ink file:px-3 file:py-2 file:text-xs file:text-bone hover:file:bg-henna"
            />
            <input
              type="url"
              name="image2"
              placeholder="…or paste an image link (https://...)"
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
            />
          </div>
        </div>

        <div className="grid gap-6 sm:grid-cols-2">
          <div>
            <label className="label-xs block text-stone mb-2">Available Sizes (Comma separated)</label>
            <input
              type="text"
              name="sizes"
              defaultValue="S, M, L, XL"
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
            />
          </div>

          <div>
            <label className="label-xs block text-stone mb-2">Key Craft Details (Comma separated)</label>
            <input
              type="text"
              name="details"
              defaultValue="Pre-shrunk fabric, Twin-needle collar rib, Machine wash cold"
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
            />
          </div>
        </div>

        <div className="flex items-center gap-6 border-t border-ink/10 pt-6">
          <label className="flex items-center gap-2 text-sm text-ink cursor-pointer">
            <input type="checkbox" name="isFeatured" className="h-4 w-4 rounded accent-ink" />
            <span>Mark as Featured Product</span>
          </label>

          <label className="flex items-center gap-2 text-sm text-ink cursor-pointer">
            <input type="checkbox" name="isNew" className="h-4 w-4 rounded accent-ink" />
            <span>Mark as New Arrival</span>
          </label>
        </div>

        <button
          type="submit"
          className="w-full rounded-lg bg-ink py-4 text-sm font-medium text-bone transition-colors hover:bg-henna"
        >
          Publish Product to Store
        </button>
      </form>
    </div>
  );
}
