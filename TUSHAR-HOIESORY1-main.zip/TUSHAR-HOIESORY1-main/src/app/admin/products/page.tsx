import Link from "next/link";
import Image from "next/image";
import { requireAdminSession, deleteProductAction } from "../actions";
import { listProducts } from "@/lib/catalog";
import { CATEGORY_LABELS, AUDIENCE_LABELS } from "@/lib/constants";

export default async function AdminProductsPage() {
  await requireAdminSession();
  const productList = await listProducts();

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-ink">Products Management</h1>
          <p className="text-xs text-graphite mt-1">
            Manage your store catalog ({productList.length} items), pricing, inventory stock, and apparel items.
          </p>
        </div>
        <Link
          href="/admin/products/new"
          className="label-sm bg-ink px-6 py-3 text-bone transition-colors hover:bg-henna rounded-lg"
        >
          + Add New Product
        </Link>
      </div>

      <div className="rounded-2xl border border-ink/10 bg-white p-6 shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-ink/10 text-stone">
                <th className="pb-3 font-medium">Image</th>
                <th className="pb-3 font-medium">Name & Details</th>
                <th className="pb-3 font-medium">Category</th>
                <th className="pb-3 font-medium">Audience</th>
                <th className="pb-3 font-medium">Price</th>
                <th className="pb-3 font-medium">Stock</th>
                <th className="pb-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/10">
              {productList.map((product) => {
                const mainImage = product.images?.[0] || "https://images.pexels.com/photos/9775825/pexels-photo-9775825.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800";

                return (
                  <tr key={product.id} className="hover:bg-bone/40">
                    <td className="py-4">
                      <div className="relative h-12 w-10 overflow-hidden rounded bg-shell">
                        <Image
                          src={mainImage}
                          alt={product.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                    </td>
                    <td className="py-4">
                      <p className="font-bold text-ink text-sm">{product.name}</p>
                      <p className="text-[11px] text-stone mt-0.5">{product.tagline}</p>
                    </td>
                    <td className="py-4">
                      <span className="label-xs rounded bg-shell px-2.5 py-1 text-ink font-medium">
                        {CATEGORY_LABELS[product.category] || product.category}
                      </span>
                    </td>
                    <td className="py-4">
                      <span className="label-xs rounded bg-bone px-2.5 py-1 text-graphite font-medium">
                        {AUDIENCE_LABELS[product.audience] || product.audience}
                      </span>
                    </td>
                    <td className="py-4 font-bold text-ink text-sm">
                      ₹{(product.priceCents / 100).toLocaleString("en-IN")}
                    </td>
                    <td className="py-4">
                      <span
                        className={`label-xs rounded px-2.5 py-1 font-semibold ${
                          product.stock <= 10
                            ? "bg-henna/15 text-henna"
                            : "bg-moss/15 text-moss"
                        }`}
                      >
                        {product.stock} in stock
                      </span>
                    </td>
                    <td className="py-4 text-right">
                      <div className="inline-flex items-center gap-2">
                        <Link
                          href={`/admin/products/${product.id}/edit`}
                          className="label-xs rounded border border-ink/20 px-3 py-1.5 text-ink transition-colors hover:bg-ink hover:text-white"
                        >
                          Edit
                        </Link>
                        <form
                          action={async () => {
                            "use server";
                            await deleteProductAction(product.id);
                          }}
                        >
                          <button
                            type="submit"
                            className="label-xs rounded border border-henna/30 px-3 py-1.5 text-henna transition-colors hover:bg-henna hover:text-white"
                          >
                            Delete
                          </button>
                        </form>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
