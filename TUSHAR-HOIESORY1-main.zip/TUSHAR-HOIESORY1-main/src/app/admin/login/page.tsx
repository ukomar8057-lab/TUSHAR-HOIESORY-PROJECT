"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { loginAdminAction } from "../actions";

export default function AdminLoginPage() {
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError(null);

    const formData = new FormData(event.currentTarget);
    const result = await loginAdminAction(formData);

    setLoading(false);

    if (result.ok) {
      router.push("/admin");
      router.refresh();
    } else {
      setError(result.error || "Login failed");
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <div className="w-full max-w-md rounded-2xl border border-ink/10 bg-white p-8 shadow-sm">
        <div className="text-center">
          <span className="font-display text-2xl tracking-widest text-ink font-bold">
            TUSHAR
          </span>
          <p className="label-xs mt-1 text-stone">Store Admin Authentication</p>
        </div>

        <form onSubmit={handleSubmit} className="mt-8 space-y-5">
          <div>
            <label className="label-xs block text-stone mb-2">Admin Email</label>
            <input
              type="email"
              name="email"
              required
              autoComplete="email"
              placeholder="Enter admin email"
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
            />
          </div>

          <div>
            <label className="label-xs block text-stone mb-2">Admin Password</label>
            <input
              type="password"
              name="password"
              required
              autoComplete="current-password"
              placeholder="Enter admin password"
              className="w-full rounded-lg border border-ink/20 px-4 py-3 text-sm text-ink outline-none focus:border-ink"
            />
          </div>

          {error && (
            <p className="text-xs text-henna bg-henna/10 p-3 rounded border border-henna/30">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-ink py-4 text-sm font-medium text-bone transition-colors hover:bg-henna disabled:opacity-60"
          >
            {loading ? "Authenticating…" : "Login to Admin Dashboard"}
          </button>
        </form>
      </div>
    </div>
  );
}
