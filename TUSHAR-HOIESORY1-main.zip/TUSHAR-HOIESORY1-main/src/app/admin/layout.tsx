import Link from "next/link";
import { verifyAdminSession, logoutAdminAction } from "./actions";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const isAuth = await verifyAdminSession();

  if (!isAuth) {
    return <div className="min-h-screen bg-bone">{children}</div>;
  }

  return (
    <div className="min-h-screen bg-bone text-ink">
      {/* Top Admin Header */}
      <header className="sticky top-0 z-40 border-b border-ink/10 bg-white/95 px-6 py-4 backdrop-blur-md">
        <div className="mx-auto flex max-w-[1600px] items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/admin" className="font-display text-xl tracking-wider text-ink font-bold">
              TUSHAR <span className="text-xs font-sans font-normal text-henna bg-henna/15 px-2 py-0.5 rounded ml-2">ADMIN PANEL</span>
            </Link>
          </div>
          <div className="flex items-center gap-4">
            <Link
              href="/"
              target="_blank"
              className="label-xs border border-ink/20 px-3 py-1.5 text-graphite transition-colors hover:bg-ink hover:text-bone rounded"
            >
              View Storefront ↗
            </Link>
            <form action={logoutAdminAction}>
              <button
                type="submit"
                className="label-xs bg-ink/10 px-3 py-1.5 text-ink transition-colors hover:bg-henna hover:text-bone rounded"
              >
                Logout
              </button>
            </form>
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1600px] grid-cols-1 lg:grid-cols-[240px_1fr]">
        {/* Admin Navigation Sidebar */}
        <aside className="border-b lg:border-b-0 lg:border-r border-ink/10 bg-white p-6">
          <nav className="flex flex-row lg:flex-col gap-2 overflow-x-auto">
            <Link
              href="/admin"
              className="label-sm flex items-center gap-3 rounded-lg px-4 py-3 text-ink transition-colors hover:bg-bone hover:font-bold"
            >
              📊 Dashboard
            </Link>
            <Link
              href="/admin/products"
              className="label-sm flex items-center gap-3 rounded-lg px-4 py-3 text-ink transition-colors hover:bg-bone hover:font-bold"
            >
              📦 Products
            </Link>
            <Link
              href="/admin/collections"
              className="label-sm flex items-center gap-3 rounded-lg px-4 py-3 text-ink transition-colors hover:bg-bone hover:font-bold"
            >
              📁 Collections
            </Link>
            <Link
              href="/admin/orders"
              className="label-sm flex items-center gap-3 rounded-lg px-4 py-3 text-ink transition-colors hover:bg-bone hover:font-bold"
            >
              🛒 Orders
            </Link>
          </nav>
        </aside>

        {/* Main Content Area */}
        <main className="p-6 sm:p-10">{children}</main>
      </div>
    </div>
  );
}
