import Image from "next/image";
import { requireAdminSession, createCollectionAction, deleteCollectionAction } from "../actions";
import { listCollections } from "@/lib/catalog";
import { ErrorBanner } from "../error-banner";

export default async function AdminCollectionsPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  await requireAdminSession();
  const collectionList = await listCollections();
  const { error } = await searchParams;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold text-ink">Collections Management</h1>
        <p className="text-xs text-graphite mt-1">
          Manage your store&apos;s seasonal collections, group banners, and kicker tags.
        </p>
      </div>

      <ErrorBanner message={error} />

      <div className="grid gap-8 lg:grid-cols-[1fr_360px]">
        {/* Collections Table */}
        <div className="rounded-2xl border border-ink/10 bg-white p-6 shadow-sm">
          <h2 className="font-display text-xl font-bold text-ink mb-4">Active Collections ({collectionList.length})</h2>
          
          <div className="space-y-4">
            {collectionList.map((collection) => (
              <div
                key={collection.id}
                className="flex flex-col gap-4 rounded-xl border border-ink/10 p-4 sm:flex-row sm:items-center sm:justify-between hover:bg-bone/40"
              >
                <div className="flex items-center gap-4">
                  <div className="relative h-16 w-20 overflow-hidden rounded bg-shell shrink-0">
                    <Image
                      src={collection.image}
                      alt={collection.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <span className="label-xs text-stone">{collection.kicker}</span>
                    <h3 className="font-display text-base font-bold text-ink">{collection.title}</h3>
                    <p className="text-xs text-graphite line-clamp-1 mt-0.5">{collection.description}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span className="label-xs rounded bg-bone px-3 py-1 text-graphite border border-ink/10">
                    /{collection.slug}
                  </span>
                  <form
                    action={async () => {
                      "use server";
                      await deleteCollectionAction(collection.id);
                    }}
                  >
                    <button
                      type="submit"
                      className="label-xs rounded border border-henna/30 px-3 py-1 text-henna hover:bg-henna hover:text-white"
                    >
                      Delete
                    </button>
                  </form>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Add Collection Form */}
        <div className="rounded-2xl border border-ink/10 bg-white p-6 shadow-sm h-fit space-y-4">
          <h2 className="font-display text-lg font-bold text-ink">Add New Collection</h2>
          <form action={createCollectionAction} className="space-y-4">
            <div>
              <label className="label-xs block text-stone mb-1.5">Collection Title *</label>
              <input
                type="text"
                name="title"
                required
                placeholder="e.g. Summer Linen Knitwear"
                className="w-full rounded-lg border border-ink/20 px-3 py-2.5 text-xs text-ink outline-none focus:border-ink"
              />
            </div>

            <div>
              <label className="label-xs block text-stone mb-1.5">Kicker Tag *</label>
              <input
                type="text"
                name="kicker"
                required
                placeholder="e.g. Core 06 or Summer Line"
                className="w-full rounded-lg border border-ink/20 px-3 py-2.5 text-xs text-ink outline-none focus:border-ink"
              />
            </div>

            <div>
              <label className="label-xs block text-stone mb-1.5">Description *</label>
              <textarea
                name="description"
                required
                rows={3}
                placeholder="Brief summary of the collection..."
                className="w-full rounded-lg border border-ink/20 px-3 py-2.5 text-xs text-ink outline-none focus:border-ink"
              />
            </div>

            <div className="space-y-2">
              <label className="label-xs block text-stone mb-1.5">Banner Image *</label>
              <input
                type="file"
                name="imageFile"
                accept="image/jpeg,image/png,image/webp,image/gif,image/avif"
                className="w-full text-xs text-graphite file:mr-3 file:rounded file:border-0 file:bg-ink file:px-3 file:py-2 file:text-xs file:text-bone hover:file:bg-henna"
              />
              <input
                type="url"
                name="image"
                placeholder="…or paste an image link (https://...)"
                className="w-full rounded-lg border border-ink/20 px-3 py-2.5 text-xs text-ink outline-none focus:border-ink"
              />
            </div>

            <button
              type="submit"
              className="w-full rounded-lg bg-ink py-3 text-xs font-medium text-bone transition-colors hover:bg-henna"
            >
              Create Collection
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
