import Link from "next/link";
import { requireAdminSession } from "./actions";
import { listProducts, listCollections, getCatalogCounts } from "@/lib/catalog";
import { db } from "@/db";
import { orders } from "@/db/schema";

export default async function AdminDashboardPage() {
  await requireAdminSession();

  const [productList, collectionList, counts] = await Promise.all([
    listProducts(),
    listCollections(),
    getCatalogCounts(),
  ]);

  const allOrders = await db
    .select({ totalCents: orders.totalCents, status: orders.status })
    .from(orders);

  const totalProducts = productList.length;
  const totalCollections = collectionList.length;
  const totalOrdersCount = allOrders.length;
  const totalRevenuePaise = allOrders
    .filter((o) => o.status !== "cancelled")
    .reduce((acc, o) => acc + o.totalCents, 0);
  const lowStockProducts = productList.filter((p) => p.stock <= 10);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold text-ink">Dashboard Overview</h1>
        <p className="text-xs text-graphite mt-1">
          Welcome back! Here is a summary of your store metrics and inventory status.
        </p>
      </div>

      {/* Metrics Grid */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-2xl border border-ink/10 bg-white p-6 shadow-sm">
          <p className="label-xs text-stone">Total Products</p>
          <p className="font-display text-4xl font-bold text-ink mt-2">{totalProducts}</p>
          <p className="text-xs text-graphite mt-1">Across {Object.keys(counts.categories).length} categories</p>
        </div>

        <div className="rounded-2xl border border-ink/10 bg-white p-6 shadow-sm">
          <p className="label-xs text-stone">Collections</p>
          <p className="font-display text-4xl font-bold text-ink mt-2">{totalCollections}</p>
          <p className="text-xs text-graphite mt-1">Active seasonal collections</p>
        </div>

        <div className="rounded-2xl border border-ink/10 bg-white p-6 shadow-sm">
          <p className="label-xs text-stone">Total Orders</p>
          <p className="font-display text-4xl font-bold text-ink mt-2">{totalOrdersCount}</p>
          <p className="text-xs text-graphite mt-1">Customer orders placed</p>
        </div>

        <div className="rounded-2xl border border-ink/10 bg-white p-6 shadow-sm">
          <p className="label-xs text-stone">Total Revenue</p>
          <p className="font-display text-4xl font-bold text-henna mt-2">
            ₹{(totalRevenuePaise / 100).toLocaleString("en-IN")}
          </p>
          <p className="text-xs text-graphite mt-1">Completed sales</p>
        </div>
      </div>

      {/* Quick Action Cards */}
      <div className="grid gap-6 sm:grid-cols-3">
        <Link
          href="/admin/products/new"
          className="group rounded-2xl border border-ink/10 bg-white p-6 transition-all hover:border-ink hover:shadow-md"
        >
          <div className="text-3xl">➕</div>
          <h3 className="font-display text-lg font-bold text-ink mt-3">Add New Product</h3>
          <p className="text-xs text-graphite mt-1">Create a new t-shirt, shirt, hoodie, jacket, or kids item.</p>
        </Link>

        <Link
          href="/admin/collections"
          className="group rounded-2xl border border-ink/10 bg-white p-6 transition-all hover:border-ink hover:shadow-md"
        >
          <div className="text-3xl">📁</div>
          <h3 className="font-display text-lg font-bold text-ink mt-3">Manage Collections</h3>
          <p className="text-xs text-graphite mt-1">Add or edit seasonal groups and collection banners.</p>
        </Link>

        <Link
          href="/admin/orders"
          className="group rounded-2xl border border-ink/10 bg-white p-6 transition-all hover:border-ink hover:shadow-md"
        >
          <div className="text-3xl">🛒</div>
          <h3 className="font-display text-lg font-bold text-ink mt-3">View Orders</h3>
          <p className="text-xs text-graphite mt-1">Track customer shipments and update order status.</p>
        </Link>
      </div>

      {/* Low Stock Warning */}
      {lowStockProducts.length > 0 && (
        <div className="rounded-2xl border border-henna/30 bg-henna/10 p-6">
          <div className="flex items-center gap-3">
            <span className="text-xl">⚠️</span>
            <div>
              <h3 className="font-display text-base font-bold text-henna">Low Stock Alert ({lowStockProducts.length} items)</h3>
              <p className="text-xs text-graphite mt-0.5">The following items have 10 or fewer units remaining in inventory:</p>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            {lowStockProducts.map((item) => (
              <span key={item.id} className="label-xs rounded bg-white px-3 py-1.5 border border-henna/40 text-ink">
                {item.name} ({item.stock} left)
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Recent Products Table */}
      <div className="rounded-2xl border border-ink/10 bg-white p-6 shadow-sm">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-xl font-bold text-ink">Recent Products Catalog</h2>
          <Link href="/admin/products" className="label-xs text-henna link-underline">
            View all products →
          </Link>
        </div>

        <div className="mt-6 overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-ink/10 text-stone">
                <th className="pb-3 font-medium">Product Name</th>
                <th className="pb-3 font-medium">Category</th>
                <th className="pb-3 font-medium">Audience</th>
                <th className="pb-3 font-medium">Price</th>
                <th className="pb-3 font-medium">Stock</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/10">
              {productList.slice(0, 6).map((product) => (
                <tr key={product.id} className="hover:bg-bone/50">
                  <td className="py-4 font-medium text-ink">{product.name}</td>
                  <td className="py-4 capitalize text-graphite">{product.category}</td>
                  <td className="py-4 capitalize text-graphite">{product.audience}</td>
                  <td className="py-4 font-semibold text-ink">₹{(product.priceCents / 100).toLocaleString("en-IN")}</td>
                  <td className="py-4">
                    <span
                      className={`label-xs rounded px-2 py-1 ${
                        product.stock <= 10
                          ? "bg-henna/15 text-henna"
                          : "bg-moss/15 text-moss"
                      }`}
                    >
                      {product.stock} units
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
