import { NextResponse } from "next/server";
import { getCartSummary } from "@/lib/cart";

export async function GET() {
  const cart = await getCartSummary();
  return NextResponse.json({
    itemCount: cart.itemCount,
    subtotalCents: cart.subtotalCents,
    shippingCents: cart.shippingCents,
    totalCents: cart.totalCents,
    lines: cart.lines.map((line) => ({
      id: line.itemId,
      name: line.product.name,
      slug: line.product.slug,
      size: line.size,
      quantity: line.quantity,
      unitPriceCents: line.product.priceCents,
    })),
  });
}
