import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Bodoni_Moda, Inter } from "next/font/google";
import "./globals.css";
import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";
import FloatingActions from "@/components/floating-actions";
import { emptyCart, getCartSummary } from "@/lib/cart";
import { listCollections } from "@/lib/catalog";

const display = Bodoni_Moda({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-bodoni",
  display: "swap",
});

const sans = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"),
  title: {
    default: "Tushar Hosiery — Knitted legwear, made in Tiruppur",
    template: "%s · Tushar Hosiery",
  },
  description:
    "Tushar Hosiery makes socks, tights, leggings and thermals knitted on vintage circular frames in Tiruppur, India. Sheer to heavy weight, made to be worn every day.",
  keywords: [
    "hosiery",
    "socks",
    "tights",
    "leggings",
    "thermals",
    "Tiruppur",
    "Tushar Hosiery",
  ],
  openGraph: {
    title: "Tushar Hosiery",
    description: "Knitted legwear made in Tiruppur since 1978.",
    type: "website",
  },
};

export const dynamic = "force-dynamic";

export default async function RootLayout({ children }: { children: ReactNode }) {
  // The header/footer must still render if the database is briefly unreachable;
  // the pages themselves still show a real error in that case.
  const [cart, collections] = await Promise.all([
    getCartSummary().catch((error) => {
      console.error("[layout] cart lookup failed:", error);
      return emptyCart;
    }),
    listCollections().catch((error) => {
      console.error("[layout] collections lookup failed:", error);
      return [];
    }),
  ]);

  return (
    <html lang="en" className={`${display.variable} ${sans.variable}`}>
      <body className="bg-bone text-ink">
        <div className="flex min-h-screen flex-col">
          <SiteHeader cartCount={cart.itemCount} collections={collections} />
          <main className="flex-1">{children}</main>
          <SiteFooter />
          <FloatingActions />
        </div>
      </body>
    </html>
  );
}
