"use client";

export default function GlobalError({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="mx-auto flex max-w-[1100px] flex-col items-start px-4 py-32 sm:px-8">
      <p className="label-xs text-henna">Something came undone</p>
      <h1 className="display-lg mt-5">A seam split.</h1>
      <p className="mt-6 max-w-md text-sm leading-relaxed text-graphite">
        We could not load this page. Our mill floor has been notified — try again, or head back to
        the collection.
      </p>
      <div className="mt-10 flex flex-wrap gap-3">
        <button
          type="button"
          onClick={reset}
          className="label-sm bg-ink px-8 py-4 text-bone transition-colors hover:bg-henna"
        >
          Try again
        </button>
        <a
          href="/shop"
          className="label-sm border border-ink/25 px-8 py-4 text-ink transition-colors hover:bg-ink hover:text-bone"
        >
          Shop the collection
        </a>
      </div>
    </div>
  );
}
