import type { MetadataRoute } from "next";
import { listCollections, listProducts } from "@/lib/catalog";

// Built on every request so new products appear without a redeploy (and the build needs no database).
export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
  const [products, collections] = await Promise.all([listProducts(), listCollections()]);

  const staticRoutes: MetadataRoute.Sitemap = [
    { url: `${base}/`, priority: 1 },
    { url: `${base}/shop`, priority: 0.9 },
    { url: `${base}/about`, priority: 0.6 },
    { url: `${base}/cart`, priority: 0.3 },
  ];

  return [
    ...staticRoutes,
    ...collections.map((collection) => ({
      url: `${base}/collections/${collection.slug}`,
      priority: 0.7,
    })),
    ...products.map((product) => ({
      url: `${base}/product/${product.slug}`,
      priority: 0.8,
    })),
  ];
}
