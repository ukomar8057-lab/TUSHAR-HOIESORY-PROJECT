"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { cartItems, carts, orderItems, orders, products, subscribers } from "@/db/schema";
import { CART_COOKIE, findCartId, getCartSummary, readCartToken } from "@/lib/cart";
import { normalizePhone } from "@/lib/phone";
import { expressShippingCents, freeShippingThreshold, standardShippingCents } from "@/lib/format";

import type { ActionState } from "@/lib/action-state";

/** Thrown inside the order transaction to roll everything back with a customer-friendly message. */
class OutOfStockError extends Error {}

function revalidateStore() {
  revalidatePath("/", "layout");
}

/** Returns the visitor's cart id, creating the cart (and its cookie) when needed. */
async function getOrCreateCartId(): Promise<number> {
  const store = await cookies();
  let token = store.get(CART_COOKIE)?.value;

  if (!token) {
    token = crypto.randomUUID();
    store.set(CART_COOKIE, token, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 30,
    });
  }

  await db.insert(carts).values({ token }).onConflictDoNothing({ target: carts.token });
  const found = await db.select({ id: carts.id }).from(carts).where(eq(carts.token, token)).limit(1);
  if (!found[0]) throw new Error("Could not create a cart.");
  return found[0].id;
}

export async function addToCartAction(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const slug = String(formData.get("slug") ?? "");
  const size = String(formData.get("size") ?? "");
  const quantity = Number(formData.get("quantity") ?? 1);

  if (!slug) return { ok: false, message: "Product not found." };
  if (!size) return { ok: false, message: "Please select a size first." };

  try {
    const rows = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
    const product = rows[0];
    if (!product) return { ok: false, message: "That piece is no longer available." };
    if (!product.sizes.includes(size)) {
      return { ok: false, message: "That size is not available for this piece." };
    }
    if (product.stock < 1) {
      return { ok: false, message: "Sorry, this piece is out of stock." };
    }

    const cartId = await getOrCreateCartId();
    const safeQuantity = Math.min(Math.max(Number.isFinite(quantity) ? Math.floor(quantity) : 1, 1), 10);

    await db
      .insert(cartItems)
      .values({ cartId, productId: product.id, size, quantity: safeQuantity })
      .onConflictDoUpdate({
        target: [cartItems.cartId, cartItems.productId, cartItems.size],
        set: { quantity: sql`LEAST(${cartItems.quantity} + ${safeQuantity}, 10)` },
      });

    revalidateStore();
    return { ok: true, message: `${product.name} · ${size} added to your bag.` };
  } catch (error) {
    console.error("[add-to-cart] failed:", error);
    return { ok: false, message: "We could not add that piece. Please try again." };
  }
}

export async function updateQuantityAction(formData: FormData): Promise<void> {
  const itemId = Number(formData.get("itemId"));
  const delta = Number(formData.get("delta") ?? 0);
  if (!Number.isInteger(itemId) || !Number.isFinite(delta)) return;

  // Only touch lines that belong to THIS visitor's cart.
  const cartId = await findCartId(await readCartToken());
  if (!cartId) return;
  const where = and(eq(cartItems.id, itemId), eq(cartItems.cartId, cartId));

  const rows = await db.select().from(cartItems).where(where).limit(1);
  const line = rows[0];
  if (!line) return;

  const next = line.quantity + Math.trunc(delta);
  if (next < 1) {
    await db.delete(cartItems).where(where);
  } else {
    await db.update(cartItems).set({ quantity: Math.min(next, 10) }).where(where);
  }
  revalidateStore();
}

export async function removeLineAction(formData: FormData): Promise<void> {
  const itemId = Number(formData.get("itemId"));
  if (!Number.isInteger(itemId)) return;

  const cartId = await findCartId(await readCartToken());
  if (!cartId) return;

  await db.delete(cartItems).where(and(eq(cartItems.id, itemId), eq(cartItems.cartId, cartId)));
  revalidateStore();
}

export async function subscribeAction(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const email = String(formData.get("email") ?? "")
    .trim()
    .toLowerCase();

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { ok: false, message: "Enter a valid email address." };
  }

  try {
    await db.insert(subscribers).values({ email }).onConflictDoNothing();
  } catch (error) {
    console.error("[subscribe] failed:", error);
    return { ok: false, message: "We could not save your email. Please try again." };
  }

  return { ok: true, message: "You are on the list. First access to every drop." };
}

// Order numbers act as the "key" to the public order page (it shows the delivery address),
// so they must be unguessable: 10 random characters = about 1 quadrillion combinations.
const ORDER_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; // no look-alike characters (0/O, 1/I/L)

function generateOrderNumber(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(10));
  let id = "";
  for (const byte of bytes) id += ORDER_ALPHABET[byte % ORDER_ALPHABET.length];
  return `TH-${id}`;
}

export async function placeOrderAction(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const fullName = String(formData.get("fullName") ?? "").trim();
  const phoneRaw = String(formData.get("phone") ?? "").trim();
  const address = String(formData.get("address") ?? "").trim();
  const city = String(formData.get("city") ?? "").trim();
  const postalCode = String(formData.get("postalCode") ?? "").trim();
  const country = String(formData.get("country") ?? "").trim();
  const shippingMethod = String(formData.get("shippingMethod") ?? "standard");

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { ok: false, message: "A valid email is required for your order confirmation." };
  }
  if (fullName.length < 2 || address.length < 5 || !city || !postalCode || !country) {
    return { ok: false, message: "Please complete every delivery field." };
  }

  const phone = normalizePhone(phoneRaw, country);
  if (!phone) {
    return {
      ok: false,
      message:
        country === "India"
          ? "Enter a valid 10-digit mobile number so we can reach you about your delivery."
          : "Enter a valid mobile number including the country code (for example +44 7700 900123).",
    };
  }

  let orderNumber: string;
  try {
    const cart = await getCartSummary();
    if (cart.lines.length === 0) {
      return { ok: false, message: "Your bag is empty." };
    }

    const shippingCents =
      shippingMethod === "express"
        ? expressShippingCents()
        : cart.subtotalCents >= freeShippingThreshold()
          ? 0
          : standardShippingCents();

    const cartId = await findCartId(await readCartToken());

    orderNumber = generateOrderNumber();
    const orderData = {
      orderNumber,
      email,
      fullName,
      phone,
      address,
      city,
      postalCode,
      country,
      shippingMethod: shippingMethod === "express" ? "express" : "standard",
      subtotalCents: cart.subtotalCents,
      shippingCents,
      totalCents: cart.subtotalCents + shippingCents,
      status: "confirmed",
    };

    // Order + items + emptying the cart happen together or not at all.
    await db.transaction(async (tx) => {
      // Stock is per product (not per size), so add up quantities first.
      const wanted = new Map<number, { name: string; quantity: number }>();
      for (const line of cart.lines) {
        const entry = wanted.get(line.product.id);
        if (entry) entry.quantity += line.quantity;
        else wanted.set(line.product.id, { name: line.product.name, quantity: line.quantity });
      }

      // Only succeeds while enough stock is left, so two buyers can never oversell the last piece.
      for (const [productId, { name, quantity }] of wanted) {
        const updated = await tx
          .update(products)
          .set({ stock: sql`${products.stock} - ${quantity}` })
          .where(and(eq(products.id, productId), sql`${products.stock} >= ${quantity}`))
          .returning({ id: products.id });
        if (updated.length === 0) {
          const current = await tx
            .select({ stock: products.stock })
            .from(products)
            .where(eq(products.id, productId))
            .limit(1);
          const left = current[0]?.stock ?? 0;
          throw new OutOfStockError(
            left > 0
              ? `Sorry, only ${left} left of ${name}. Please lower the quantity in your bag.`
              : `Sorry, ${name} just sold out. Please remove it from your bag.`,
          );
        }
      }

      const inserted = await tx.insert(orders).values(orderData).returning({ id: orders.id });
      const orderId = inserted[0].id;

      await tx.insert(orderItems).values(
        cart.lines.map((line) => ({
          orderId,
          productId: line.product.id,
          name: line.product.name,
          slug: line.product.slug,
          image: line.product.images[0] ?? "",
          size: line.size,
          quantity: line.quantity,
          unitPriceCents: line.product.priceCents,
        })),
      );

      if (cartId) {
        await tx.delete(cartItems).where(eq(cartItems.cartId, cartId));
      }
    });
  } catch (error) {
    if (error instanceof OutOfStockError) {
      return { ok: false, message: error.message };
    }
    console.error("[place-order] failed:", error);
    return { ok: false, message: "We could not place your order. Please try again." };
  }

  revalidateStore();
  redirect(`/order/${orderNumber}`);
}

export async function clearCartAction(): Promise<void> {
  const cartId = await findCartId(await readCartToken());
  if (cartId) {
    await db.delete(cartItems).where(eq(cartItems.cartId, cartId));
  }
  revalidateStore();
}
