import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getOrderByNumber } from "@/lib/orders";
import { formatPrice } from "@/lib/format";
import { formatPhone } from "@/lib/phone";

type Params = { number: string };

export const metadata: Metadata = { title: "Order confirmed" };

const steps = ["Order placed", "Knitting floor check", "Packed in Tiruppur", "In transit", "Delivered"];

export default async function OrderPage({ params }: { params: Promise<Params> }) {
  const { number } = await params;
  const result = await getOrderByNumber(number);
  if (!result) notFound();

  const { order, items } = result;
  const eta = new Date(order.createdAt);
  eta.setDate(eta.getDate() + (order.shippingMethod === "express" ? 3 : 6));

  return (
    <div className="mx-auto max-w-[1100px] px-4 py-16 sm:px-8 sm:py-24">
      <p className="label-xs text-henna">Thank you</p>
      <h1 className="display-lg mt-5">Order {order.orderNumber}</h1>
      <p className="mt-5 max-w-xl text-sm leading-relaxed text-graphite">
        Confirmed. A receipt is on its way to {order.email}. We pack everything by hand in Tiruppur
        and dispatch within twenty-four hours.
      </p>

      <div className="mt-12 grid gap-10 lg:grid-cols-[1.5fr_1fr] lg:gap-16">
        <div>
          <div className="border border-ink/15">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-ink/15 px-6 py-5">
              <span className="label-xs text-stone">Your order</span>
              <span className="label-xs text-moss">Confirmed</span>
            </div>
            <ul className="divide-y divide-ink/10">
              {items.map((item) => (
                <li key={item.id} className="flex gap-5 px-6 py-5">
                  <Link href={`/product/${item.slug}`} className="relative h-28 w-20 shrink-0 overflow-hidden bg-shell">
                    <Image src={item.image} alt={item.name} fill sizes="100px" className="object-cover" />
                  </Link>
                  <div className="flex flex-1 flex-col">
                    <Link href={`/product/${item.slug}`} className="text-sm font-medium hover:text-henna">
                      {item.name}
                    </Link>
                    <p className="mt-1 text-[11px] text-stone">Size {item.size} · Qty {item.quantity}</p>
                    <p className="mt-auto pt-3 text-[11px] text-stone">
                      {formatPrice(item.unitPriceCents)} each
                    </p>
                  </div>
                  <p className="text-sm">{formatPrice(item.unitPriceCents * item.quantity)}</p>
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-10">
            <p className="label-xs text-stone">Progress</p>
            <ol className="mt-5 grid gap-4 sm:grid-cols-5">
              {steps.map((step, index) => (
                <li key={step} className="flex items-start gap-3 sm:flex-col">
                  <span
                    className={`h-px w-8 ${index === 0 ? "bg-henna" : "bg-ink/20"} sm:h-8 sm:w-px`}
                  />
                  <span
                    className={`label-xs ${index === 0 ? "text-henna" : "text-stone"}`}
                  >
                    {step}
                  </span>
                </li>
              ))}
            </ol>
          </div>
        </div>

        <aside className="space-y-6">
          <div className="border border-ink/15 p-7">
            <p className="label-xs text-stone">Summary</p>
            <div className="mt-6 space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-graphite">Subtotal</span>
                <span>{formatPrice(order.subtotalCents)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-graphite">
                  Shipping · {order.shippingMethod === "express" ? "Express" : "Standard"}
                </span>
                <span>{order.shippingCents === 0 ? "Free" : formatPrice(order.shippingCents)}</span>
              </div>
              <div className="flex items-baseline justify-between border-t border-ink/15 pt-4">
                <span className="label-xs text-graphite">Total</span>
                <span className="font-display text-3xl">{formatPrice(order.totalCents)}</span>
              </div>
            </div>
          </div>

          <div className="border border-ink/15 p-7">
            <p className="label-xs text-stone">Delivering to</p>
            <address className="mt-5 space-y-1 text-xs not-italic leading-relaxed text-graphite">
              <p className="text-sm text-ink">{order.fullName}</p>
              <p>{order.address}</p>
              <p>
                {order.city} {order.postalCode}
              </p>
              <p>{order.country}</p>
              {order.phone ? <p>Mobile: {formatPhone(order.phone)}</p> : null}
            </address>
            <p className="mt-5 text-[11px] text-stone">
              Estimated arrival {eta.toLocaleDateString("en-IN", { day: "numeric", month: "long" })}
            </p>
          </div>

          <Link
            href="/shop"
            className="label-sm block bg-ink px-8 py-5 text-center text-bone transition-colors hover:bg-henna"
          >
            Continue shopping
          </Link>
        </aside>
      </div>
    </div>
  );
}
