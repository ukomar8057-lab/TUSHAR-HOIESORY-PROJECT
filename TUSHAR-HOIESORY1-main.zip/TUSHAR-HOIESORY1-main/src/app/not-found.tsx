import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-[1100px] flex-col items-start px-4 py-32 sm:px-8">
      <p className="label-xs text-henna">404</p>
      <h1 className="display-xl mt-5">Off the floor.</h1>
      <p className="mt-6 max-w-md text-sm leading-relaxed text-graphite">
        This page has either been restocked out or never existed. Try the collection — everything we
        currently make is on it.
      </p>
      <div className="mt-10 flex flex-wrap gap-3">
        <Link href="/shop" className="label-sm bg-ink px-8 py-4 text-bone hover:bg-henna">
          Shop everything
        </Link>
        <Link
          href="/"
          className="label-sm border border-ink/25 px-8 py-4 text-ink transition-colors hover:bg-ink hover:text-bone"
        >
          Back home
        </Link>
      </div>
    </div>
  );
}
