import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";

export const metadata: Metadata = {
  title: "The Mill",
  description:
    "Three generations of knitters & tailors in Tiruppur, Tamil Nadu. How Tushar Hosiery crafts clothing outfits for men, boys, girls, and kids.",
};

const timeline = [
  { year: "1978", title: "One frame", copy: "Tushar Chettiar buys a single 84-needle circular frame and knits vest cotton for the local market." },
  { year: "1986", title: "The first shirt", copy: "A consignment of 4,000 combed cotton shirts ships to a Chennai distributor. The standard is set." },
  { year: "1994", title: "Apparel Line", copy: "Full clothing outfits enter the line. Heavy loopback hoodies and selvedge denim process established." },
  { year: "2011", title: "Second generation", copy: "Meena Tushar takes over finishing and sets the hand-finished quality standard across every style." },
  { year: "2026", title: "Direct to you", copy: "Thirty-one frames, five groups, one price all year. No middlemen, no seasonal discounting." },
];

const faqs = [
  {
    q: "How should I wash my garments?",
    a: "Cotton tees, hoodies, and joggers go in the machine at 30°C, inside out. Denim and jackets should be cold washed and dried flat away from direct sun. Never tumble dry on high heat.",
  },
  {
    q: "Why does your clothing outlast high street fast fashion?",
    a: "Because we use 260–420 GSM heavy fabrics and long-staple combed cotton spun slowly on vintage machines, ensuring garments hold shape after fifty washes.",
  },
  {
    q: "What is your return policy?",
    a: "Thirty days, worn or unworn, no questions asked. We ask that you tell us what went wrong so the pattern can be corrected on the floor.",
  },
  {
    q: "Do you offer free shipping?",
    a: "Yes! Free shipping on every order above ₹3,000 across India.",
  },
];

export default function AboutPage() {
  return (
    <div>
      <section className="relative">
        <div className="relative h-[62vh] min-h-[420px] w-full overflow-hidden">
          <Image
            src="https://images.pexels.com/photos/9604298/pexels-photo-9604298.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"
            alt="The Tushar Hosiery knitting floor"
            fill
            priority
            sizes="100vw"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/30 to-ink/10" />
          <div className="absolute inset-0 flex flex-col justify-end px-4 pb-16 sm:px-8">
            <div className="mx-auto w-full max-w-[1600px]">
              <p className="label-xs text-bone/75">Tiruppur, Tamil Nadu</p>
              <h1 className="display-xl mt-4 text-bone">The mill</h1>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1600px] px-4 py-20 sm:px-8 sm:py-28">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr] lg:gap-20">
          <div>
            <p className="label-xs text-henna">Since 1978</p>
            <h2 className="display-lg mt-5">Crafting essential apparel.</h2>
          </div>
          <div className="space-y-6 text-sm leading-relaxed text-graphite sm:text-base">
            <p>
              Tushar Hosiery focuses on high-quality clothing outfits for Men, Boys, Girls, and Kids.
              For forty-eight years we have knitted and tailored premium cotton garments in one building on Kumaran Road.
            </p>
            <p>
              Every garment goes through rigorous checks under one roof. From combed yarn selection to final seam stitching,
              we ensure every tee, shirt, hoodie, jacket, and kids outfit is built to last.
            </p>
            <p>
              Everything is knitted in small batches of three hundred. When a batch is gone it is gone
              until the fabric arrives again, which is why we do not discount and never compromise on fabric density.
            </p>
          </div>
        </div>
      </section>

      <section id="craft" className="border-y border-ink/10 bg-shell/40">
        <div className="mx-auto max-w-[1600px] px-4 py-20 sm:px-8 sm:py-28">
          <p className="label-xs text-stone">Craft & materials</p>
          <h2 className="display-lg mt-4">Five decisions, made once</h2>
          <div className="mt-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-5">
            {[
              { title: "Cotton", copy: "Long-staple combed cotton and organic yarns sourced directly from ethical mills." },
              { title: "Density", copy: "260 GSM single jersey to 420 GSM loopback fleece for structured, non-sagging drape." },
              { title: "Stitching", copy: "Double and triple-needle seams throughout for maximum durability." },
              { title: "Dye", copy: "Azofree reactive dyes, dyed in-house with 80% water recirculation." },
              { title: "Finish", copy: "Pre-shrunk, pre-washed for velvety hand-feel and consistent fitting." },
            ].map((item) => (
              <div key={item.title} className="border-t border-ink/20 pt-5">
                <h3 className="display-md">{item.title}</h3>
                <p className="mt-3 text-xs leading-relaxed text-graphite">{item.copy}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1600px] px-4 py-20 sm:px-8 sm:py-28">
        <p className="label-xs text-stone">Timeline</p>
        <h2 className="display-lg mt-4">Forty-eight years, five turns</h2>
        <ol className="mt-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-5">
          {timeline.map((entry) => (
            <li key={entry.year} className="border-t border-ink/20 pt-5">
              <p className="font-display text-4xl text-henna">{entry.year}</p>
              <p className="label-xs mt-4 text-ink">{entry.title}</p>
              <p className="mt-3 text-xs leading-relaxed text-graphite">{entry.copy}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="relative">
        <div className="relative h-[58vh] min-h-[380px] w-full overflow-hidden">
          <Image src="https://www.theundone.com/cdn/shop/articles/The-Undone_Charlie_May_Drop_Shoulder_Coat_LS_2.jpg?v=1474416186" alt="Clothing craftsmanship" fill sizes="100vw" className="object-cover" />
          <div className="absolute inset-0 bg-ink/45" />
          <div className="absolute inset-0 flex items-center px-4 sm:px-8">
            <div className="mx-auto w-full max-w-[1600px]">
              <h2 className="display-lg max-w-lg text-bone">
                Standards set in 1986 and never compromised.
              </h2>
            </div>
          </div>
        </div>
      </section>

      <section id="responsibility" className="mx-auto max-w-[1600px] px-4 py-20 sm:px-8 sm:py-28">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-20">
          <div>
            <p className="label-xs text-henna">Responsibility</p>
            <h2 className="display-lg mt-5">The unglamorous work</h2>
            <p className="mt-6 text-sm leading-relaxed text-graphite">
              Sustainability in apparel is mostly about making durable clothes that last for years. We produce in small
              batches, and we zero-waste cut all fabric scraps into small accessory patches.
            </p>
          </div>
          <dl className="grid grid-cols-2 gap-8 self-start">
            {[
              { value: "94%", label: "Water recirculated in dyeing" },
              { value: "0", label: "Air-freighted parcels" },
              { value: "100%", label: "Recyclable packaging" },
              { value: "260+", label: "GSM heavy fabric weight" },
            ].map((stat) => (
              <div key={stat.label} className="border-t border-ink/20 pt-5">
                <dt className="font-display text-4xl">{stat.value}</dt>
                <dd className="label-xs mt-3 text-stone">{stat.label}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      <section id="care" className="border-y border-ink/10 bg-shell/40 text-ink">
        <div className="mx-auto max-w-[1600px] px-4 py-20 sm:px-8 sm:py-28">
          <p className="label-xs text-stone">Wash & care</p>
          <h2 className="display-lg mt-4 text-ink">Make your clothes last</h2>
          <div className="mt-14 grid gap-10 sm:grid-cols-3">
            {[
              { title: "Wash cold", copy: "30°C maximum, inside out. Cold washing preserves fiber density and rich color." },
              { title: "Air dry", copy: "Hang dry away from direct scorching sun to prevent shrinkage." },
              { title: "Store flat", copy: "Fold heavy knitwear and hoodies to maintain neck and shoulder shape." },
            ].map((item) => (
              <div key={item.title} className="border-t border-ink/20 pt-5">
                <h3 className="display-md text-ink">{item.title}</h3>
                <p className="mt-3 text-xs leading-relaxed text-graphite">{item.copy}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="shipping" className="mx-auto max-w-[1600px] px-4 py-20 sm:px-8 sm:py-28">
        <div className="grid gap-12 lg:grid-cols-3">
          <div>
            <p className="label-xs text-henna">Shipping & returns</p>
            <h2 className="display-lg mt-5">From the floor to your door</h2>
          </div>
          <div className="space-y-6 text-sm leading-relaxed text-graphite lg:col-span-2">
            <p>
              Orders placed before 4pm IST are dispatched the same working day from Tiruppur.
              Standard delivery is ₹99 and takes 4–6 working days; orders above ₹3,000 ship free.
              Express is ₹249 and arrives in 2–3 working days, fully tracked.
            </p>
            <p>
              Returns are open for thirty days from delivery, worn or unworn.
            </p>
          </div>
        </div>
      </section>

      <section id="faq" className="border-t border-ink/10 bg-shell/40">
        <div className="mx-auto max-w-[1100px] px-4 py-20 sm:px-8 sm:py-28">
          <p className="label-xs text-stone">FAQ</p>
          <h2 className="display-lg mt-4">Questions we get weekly</h2>
          <div className="mt-12 divide-y divide-ink/15 border-t border-ink/15">
            {faqs.map((faq) => (
              <details key={faq.q} className="group py-6">
                <summary className="flex cursor-pointer items-center justify-between gap-6 text-sm font-medium text-ink">
                  {faq.q}
                  <span className="text-stone transition-transform group-open:rotate-45">+</span>
                </summary>
                <p className="mt-4 text-xs leading-relaxed text-graphite">{faq.a}</p>
              </details>
            ))}
          </div>

          <div className="mt-16 flex flex-col gap-6 border-t border-ink/15 pt-12 sm:flex-row sm:items-center sm:justify-between">
            <p className="display-md max-w-md">Still crafting, still one building.</p>
            <Link
              href="/shop"
              className="label-sm shrink-0 bg-ink px-8 py-4 text-bone transition-colors hover:bg-henna"
            >
              Shop the collection
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
