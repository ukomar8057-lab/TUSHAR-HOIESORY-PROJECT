/**
 * Mobile number helpers.
 * India: exactly 10 digits starting with 6-9 (a leading +91, 91 or 0 is accepted and removed).
 * Other countries: 7-15 digits (include the country code).
 * The saved format is always international, like +919149093539.
 */
export function normalizePhone(raw: string, country: string): string | null {
  const hasPlus = raw.trim().startsWith("+");
  let digits = raw.replace(/\D/g, "");
  if (!digits) return null;

  if (country === "India") {
    if (digits.length === 12 && digits.startsWith("91")) digits = digits.slice(2);
    else if (digits.length === 11 && digits.startsWith("0")) digits = digits.slice(1);
    return /^[6-9]\d{9}$/.test(digits) ? `+91${digits}` : null;
  }

  if (digits.length < 7 || digits.length > 15) return null;
  return hasPlus ? `+${digits}` : digits;
}

/** +919149093539 -> "+91 91490 93539" (other numbers are shown as saved). */
export function formatPhone(phone: string): string {
  const match = /^\+91(\d{5})(\d{5})$/.exec(phone);
  return match ? `+91 ${match[1]} ${match[2]}` : phone;
}
