import { cache } from "react";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { getSupabaseEnv } from "@/lib/supabase/env";

export type AdminUser = { id: string; email: string | null };

/** True when profiles.role is 'admin'. Throws if the database cannot be reached. */
export async function hasAdminRole(userId: string): Promise<boolean> {
  const rows = await db
    .select({ role: profiles.role })
    .from(profiles)
    .where(eq(profiles.id, userId))
    .limit(1);
  return rows[0]?.role === "admin";
}

/**
 * Returns the signed-in admin, or null.
 * 1) Supabase verifies the login token (getUser talks to Supabase Auth, so it cannot be faked)
 * 2) The `profiles` table must say role = 'admin'
 * Cached per request so layout + page + action only pay for it once.
 */
export const getAdminUser = cache(async (): Promise<AdminUser | null> => {
  if (!getSupabaseEnv()) return null;
  try {
    const supabase = await createSupabaseServerClient();
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) return null;

    if (!(await hasAdminRole(data.user.id))) return null;

    return { id: data.user.id, email: data.user.email ?? null };
  } catch (error) {
    console.error("[admin-auth] check failed:", error);
    return null;
  }
});
