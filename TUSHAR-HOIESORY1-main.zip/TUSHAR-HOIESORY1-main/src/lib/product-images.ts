import { createSupabaseServerClient } from "@/lib/supabase/server";

export const IMAGE_BUCKET = "product-images";
const MAX_BYTES = 5 * 1024 * 1024; // 5 MB (same limit as the bucket)
const EXTENSIONS: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
  "image/avif": "avif",
};

/** True when the form really contains a chosen file (empty file inputs send a 0-byte File). */
export function hasFile(value: FormDataEntryValue | null): value is File {
  return typeof value === "object" && value !== null && "size" in value && value.size > 0;
}

/**
 * Uploads an image to Supabase Storage using the signed-in admin's session
 * (the bucket policy only allows admins) and returns its public URL.
 */
export async function uploadProductImage(file: File): Promise<string> {
  const ext = EXTENSIONS[file.type];
  if (!ext) throw new Error("Image must be a JPG, PNG, WEBP, GIF or AVIF file.");
  if (file.size > MAX_BYTES) throw new Error("Image is too large. Maximum size is 5 MB.");

  const supabase = await createSupabaseServerClient();
  const path = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}.${ext}`;

  const { error } = await supabase.storage
    .from(IMAGE_BUCKET)
    .upload(path, file, { contentType: file.type, cacheControl: "31536000", upsert: false });
  if (error) {
    throw new Error(
      `Image upload failed: ${error.message}. Check that the setup SQL was run and you are signed in as admin.`,
    );
  }

  return supabase.storage.from(IMAGE_BUCKET).getPublicUrl(path).data.publicUrl;
}
