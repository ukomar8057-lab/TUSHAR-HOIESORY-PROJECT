import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders, type Order, type OrderItem } from "@/db/schema";

export type OrderWithItems = { order: Order; items: OrderItem[] };

export async function getOrderByNumber(orderNumber: string): Promise<OrderWithItems | null> {
  const rows = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber)).limit(1);
  const order = rows[0];
  if (!order) return null;

  const items = await db
    .select()
    .from(orderItems)
    .where(eq(orderItems.orderId, order.id))
    .orderBy(asc(orderItems.id));
  return { order, items };
}
