import { cookies } from "next/headers";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { cartItems, carts, products, type Product } from "@/db/schema";
import { freeShippingThreshold } from "@/lib/format";

export const CART_COOKIE = "th_cart_token";

export type CartLine = {
  itemId: number;
  quantity: number;
  size: string;
  product: Product;
  lineTotalCents: number;
};

export type CartSummary = {
  lines: CartLine[];
  itemCount: number;
  subtotalCents: number;
  shippingCents: number;
  totalCents: number;
  remainingForFreeShipping: number;
};

export const emptyCart: CartSummary = {
  lines: [],
  itemCount: 0,
  subtotalCents: 0,
  shippingCents: 0,
  totalCents: 0,
  remainingForFreeShipping: freeShippingThreshold(),
};

export async function readCartToken(): Promise<string | null> {
  const store = await cookies();
  return store.get(CART_COOKIE)?.value ?? null;
}

export async function findCartId(token: string | null): Promise<number | null> {
  if (!token) return null;
  const rows = await db.select({ id: carts.id }).from(carts).where(eq(carts.token, token)).limit(1);
  return rows[0]?.id ?? null;
}

export async function getCartSummary(): Promise<CartSummary> {
  const token = await readCartToken();
  const cartId = await findCartId(token);
  if (!cartId) return emptyCart;

  const rows = await db
    .select({
      itemId: cartItems.id,
      quantity: cartItems.quantity,
      size: cartItems.size,
      product: products,
    })
    .from(cartItems)
    .innerJoin(products, eq(products.id, cartItems.productId))
    .where(eq(cartItems.cartId, cartId))
    .orderBy(asc(cartItems.createdAt));

  const lines: CartLine[] = rows.map((row) => ({
    itemId: row.itemId,
    quantity: row.quantity,
    size: row.size,
    product: row.product,
    lineTotalCents: row.quantity * row.product.priceCents,
  }));

  const subtotalCents = lines.reduce((sum, line) => sum + line.lineTotalCents, 0);
  const itemCount = lines.reduce((sum, line) => sum + line.quantity, 0);
  const threshold = freeShippingThreshold();
  const shippingCents = subtotalCents === 0 || subtotalCents >= threshold ? 0 : 9900;

  return {
    lines,
    itemCount,
    subtotalCents,
    shippingCents,
    totalCents: subtotalCents + shippingCents,
    remainingForFreeShipping: Math.max(0, threshold - subtotalCents),
  };
}
