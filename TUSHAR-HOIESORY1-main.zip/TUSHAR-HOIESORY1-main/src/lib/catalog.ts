import { and, asc, desc, eq, ilike, inArray, or, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { collections, products, type Collection, type Product } from "@/db/schema";
import { AUDIENCE_LABELS, CATEGORY_LABELS } from "@/lib/constants";

export { AUDIENCE_LABELS, CATEGORY_LABELS, SORT_OPTIONS } from "@/lib/constants";

export type CatalogFilters = {
  category?: string;
  audience?: string;
  collection?: string;
  q?: string;
  sort?: string;
};

export async function listProducts(filters: CatalogFilters = {}): Promise<Product[]> {
  const conditions: SQL[] = [];

  if (filters.category && CATEGORY_LABELS[filters.category]) {
    conditions.push(eq(products.category, filters.category));
  }
  if (filters.audience && AUDIENCE_LABELS[filters.audience]) {
    const audienceCondition = or(
      eq(products.audience, filters.audience),
      eq(products.audience, "unisex"),
    );
    if (audienceCondition) conditions.push(audienceCondition);
  }
  if (filters.collection) {
    conditions.push(eq(products.collectionSlug, filters.collection));
  }
  if (filters.q) {
    const term = `%${filters.q.trim()}%`;
    const searchCondition = or(
      ilike(products.name, term),
      ilike(products.tagline, term),
      ilike(products.description, term),
      ilike(products.category, term),
      ilike(products.colorName, term),
      ilike(products.fabric, term),
    );
    if (searchCondition) conditions.push(searchCondition);
  }

  const orderBy = (() => {
    switch (filters.sort) {
      case "price-asc":
        return [asc(products.priceCents)];
      case "price-desc":
        return [desc(products.priceCents)];
      case "rating":
        return [desc(products.rating), desc(products.reviewCount)];
      case "new":
        return [desc(products.isNew), asc(products.sortOrder)];
      default:
        return [asc(products.sortOrder)];
    }
  })();

  const base = db.select().from(products);
  const query = conditions.length > 0 ? base.where(and(...conditions)) : base;
  return query.orderBy(...orderBy);
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const rows = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function getProductById(id: number): Promise<Product | null> {
  const rows = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function getProductsByIds(ids: number[]): Promise<Product[]> {
  if (ids.length === 0) return [];
  return db.select().from(products).where(inArray(products.id, ids));
}

export async function getFeaturedProducts(limit = 8): Promise<Product[]> {
  return db
    .select()
    .from(products)
    .where(eq(products.isFeatured, true))
    .orderBy(asc(products.sortOrder))
    .limit(limit);
}

export async function getNewArrivals(limit = 4): Promise<Product[]> {
  return db
    .select()
    .from(products)
    .where(eq(products.isNew, true))
    .orderBy(asc(products.sortOrder))
    .limit(limit);
}

export async function getRelatedProducts(product: Product, limit = 4): Promise<Product[]> {
  const rows = await db
    .select()
    .from(products)
    .where(eq(products.collectionSlug, product.collectionSlug))
    .orderBy(asc(products.sortOrder))
    .limit(limit + 1);
  return rows.filter((row) => row.id !== product.id).slice(0, limit);
}

export async function listCollections(): Promise<Collection[]> {
  return db.select().from(collections).orderBy(asc(collections.sortOrder));
}

export async function getCollectionBySlug(slug: string): Promise<Collection | null> {
  const rows = await db.select().from(collections).where(eq(collections.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function getCatalogCounts(): Promise<{ total: number; categories: Record<string, number> }> {
  const rows = await db.select({ category: products.category }).from(products);
  const categories: Record<string, number> = {};
  for (const row of rows) {
    categories[row.category] = (categories[row.category] ?? 0) + 1;
  }
  return { total: rows.length, categories };
}
