export const CATEGORY_LABELS: Record<string, string> = {
  tshirts: "T-Shirts",
  shirts: "Shirts",
  jeans: "Jeans",
  hoodies: "Hoodies",
  trackpants: "Track Pants",
  jackets: "Jackets",
  sweaters: "Sweaters",
  shorts: "Shorts",
  dresses: "Dresses & Frocks",
  sets: "Co-ord Sets",
  kidswear: "Kids Wear",
};

export const AUDIENCE_LABELS: Record<string, string> = {
  men: "Men",
  boys: "Boys",
  girls: "Girls",
  kids: "Kids",
  unisex: "Unisex",
};

export const SORT_OPTIONS = [
  { value: "featured", label: "Featured" },
  { value: "new", label: "Newest" },
  { value: "price-asc", label: "Price: low to high" },
  { value: "price-desc", label: "Price: high to low" },
  { value: "rating", label: "Top rated" },
] as const;

export const FREE_SHIPPING_THRESHOLD = 300000; // ₹3,000 in paise
export const STANDARD_SHIPPING = 9900; // ₹99
export const EXPRESS_SHIPPING = 24900; // ₹249
