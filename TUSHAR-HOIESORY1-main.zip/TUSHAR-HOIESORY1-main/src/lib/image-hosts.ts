/**
 * Image hosts that next/image is allowed to load.
 * KEEP IN SYNC with `images.remotePatterns` in next.config.ts.
 * Pasting an image URL from any other host would crash the page, so the admin
 * forms check URLs against this list and ask for a file upload instead.
 */
const STATIC_HOSTS = ["images.pexels.com", "www.theundone.com", "cdn.shopify.com"];

export function supabaseHost(): string | null {
  try {
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    return url ? new URL(url).hostname : null;
  } catch {
    return null;
  }
}

export function allowedImageHosts(): string[] {
  const host = supabaseHost();
  return host ? [...STATIC_HOSTS, host] : STATIC_HOSTS;
}

export function isAllowedImageUrl(value: string): boolean {
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" && url.protocol !== "http:") return false;
    return allowedImageHosts().includes(url.hostname);
  } catch {
    return false;
  }
}
