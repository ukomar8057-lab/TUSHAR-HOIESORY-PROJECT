import {
  EXPRESS_SHIPPING,
  FREE_SHIPPING_THRESHOLD,
  STANDARD_SHIPPING,
} from "@/lib/constants";

export function formatPrice(paise: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(paise / 100);
}

export function ratingToStars(rating: number): string {
  const value = rating / 10;
  const full = Math.floor(value);
  const half = value - full >= 0.5;
  return "★".repeat(full) + (half ? "½" : "");
}

export function freeShippingThreshold(): number {
  return FREE_SHIPPING_THRESHOLD;
}

export function standardShippingCents(): number {
  return STANDARD_SHIPPING;
}

export function expressShippingCents(): number {
  return EXPRESS_SHIPPING;
}
