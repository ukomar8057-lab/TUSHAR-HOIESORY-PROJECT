"use client";

import Link from "next/link";
import { useActionState, useState } from "react";
import { addToCartAction } from "@/app/actions";
import { initialActionState } from "@/lib/action-state";
import { formatPrice } from "@/lib/format";

type Props = {
  slug: string;
  name: string;
  priceCents: number;
  sizes: string[];
};

export default function AddToCartForm({ slug, name, priceCents, sizes }: Props) {
  const [size, setSize] = useState<string>("");
  const [quantity, setQuantity] = useState(1);
  const [state, formAction, pending] = useActionState(addToCartAction, initialActionState);

  return (
    <form action={formAction} className="mt-10">
      <input type="hidden" name="slug" value={slug} />
      <input type="hidden" name="size" value={size} />
      <input type="hidden" name="quantity" value={quantity} />

      <div className="flex items-baseline justify-between">
        <p className="label-xs text-graphite">Select size</p>
        <span className="label-xs text-stone">Size guide</span>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {sizes.map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => setSize(option)}
            className={`min-w-[64px] border px-4 py-3 text-xs tracking-[0.15em] transition-colors ${
              size === option
                ? "border-ink bg-ink text-bone"
                : "border-ink/25 text-graphite hover:border-ink hover:text-ink"
            }`}
          >
            {option}
          </button>
        ))}
      </div>

      <div className="mt-8 flex items-center justify-between border-y border-ink/15 py-5">
        <div className="flex items-center gap-5">
          <span className="label-xs text-stone">Qty</span>
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setQuantity((value) => Math.max(1, value - 1))}
              className="text-lg text-graphite hover:text-ink"
              aria-label="Decrease quantity"
            >
              −
            </button>
            <span className="w-6 text-center text-sm">{quantity}</span>
            <button
              type="button"
              onClick={() => setQuantity((value) => Math.min(10, value + 1))}
              className="text-lg text-graphite hover:text-ink"
              aria-label="Increase quantity"
            >
              +
            </button>
          </div>
        </div>
        <p className="font-display text-2xl">{formatPrice(priceCents * quantity)}</p>
      </div>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <button
          type="submit"
          disabled={pending}
          className="label-sm flex-1 bg-ink px-8 py-5 text-bone transition-colors hover:bg-henna disabled:opacity-60"
        >
          {pending ? "Adding…" : "Add to bag"}
        </button>
        <Link
          href="/cart"
          className="label-sm border border-ink/25 px-8 py-5 text-center text-ink transition-colors hover:bg-ink hover:text-bone"
        >
          View bag
        </Link>
      </div>

      {state.message && (
        <div
          className={`mt-5 flex flex-wrap items-center justify-between gap-3 border px-4 py-3 text-xs ${
            state.ok ? "border-moss/40 bg-moss/10 text-moss" : "border-henna/40 bg-henna/10 text-henna"
          }`}
        >
          <span>{state.message}</span>
          {state.ok && (
            <Link href="/checkout" className="label-xs link-underline">
              Checkout →
            </Link>
          )}
        </div>
      )}

      {!state.ok && !state.message && (
        <p className="mt-5 text-[11px] text-stone">
          {name} ships within 24 hours from Tiruppur. Free returns for 30 days.
        </p>
      )}
    </form>
  );
}
