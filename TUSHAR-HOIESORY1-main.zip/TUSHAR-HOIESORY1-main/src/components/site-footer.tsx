import Link from "next/link";
import NewsletterForm from "@/components/newsletter-form";

const columns = [
  {
    title: "Shop",
    links: [
      { href: "/shop?category=tshirts", label: "T-Shirts" },
      { href: "/shop?category=shirts", label: "Shirts" },
      { href: "/shop?category=jeans", label: "Jeans" },
      { href: "/shop?category=hoodies", label: "Hoodies" },
      { href: "/shop?category=socks", label: "Socks & Tights" },
      { href: "/shop?sort=new", label: "New Arrivals" },
    ],
  },
  {
    title: "House",
    links: [
      { href: "/about", label: "The Mill" },
      { href: "/about#craft", label: "Craft & Materials" },
      { href: "/about#responsibility", label: "Responsibility" },
      { href: "/about#stores", label: "Stockists" },
    ],
  },
  {
    title: "Care",
    links: [
      { href: "/about#care", label: "Wash & Care" },
      { href: "/cart", label: "Your Bag" },
      { href: "/about#shipping", label: "Shipping & Returns" },
      { href: "/about#faq", label: "FAQ" },
    ],
  },
];

export default function SiteFooter() {
  return (
    <footer className="border-t border-ink/10 bg-ink text-bone">
      <div className="mx-auto max-w-[1600px] px-4 py-16 sm:px-8 sm:py-20">
        <div className="grid gap-14 lg:grid-cols-[1.4fr_2fr]">
          <div>
            <p className="font-display text-2xl tracking-[0.3em]">TUSHAR HOSIERY</p>
            <p className="mt-6 max-w-md text-sm leading-relaxed text-bone/70">
              Three generations of knitters working out of a single mill in Tiruppur, Tamil Nadu.
              We knit legwear in small batches, on machines older than most of the people
              operating them.
            </p>
            <p className="mt-6 text-sm text-bone/70">
              Call or WhatsApp:{" "}
              <a
                href="tel:+919149093539"
                className="link-underline text-bone/85 hover:text-bone"
              >
                +91 91490 93539
              </a>
            </p>
            <div className="mt-10 max-w-md">
              <p className="label-xs text-bone/60">Join the list</p>
              <NewsletterForm tone="dark" />
            </div>
          </div>

          <div className="grid gap-10 sm:grid-cols-3">
            {columns.map((column) => (
              <div key={column.title}>
                <p className="label-xs text-bone/50">{column.title}</p>
                <ul className="mt-5 space-y-3">
                  {column.links.map((link) => (
                    <li key={link.href}>
                      <Link href={link.href} className="link-underline text-sm text-bone/85 hover:text-bone">
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-4 border-t border-bone/15 pt-8 text-bone/50 sm:flex-row sm:items-center sm:justify-between">
          <p className="label-xs">© {new Date().getFullYear()} Tushar Hosiery Pvt. Ltd.</p>
          <div className="flex flex-wrap items-center gap-5">
            <span className="label-xs">Tiruppur · Mumbai · London</span>
            <span className="label-xs">Cash on Delivery</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
