import Image from "next/image";
import Link from "next/link";
import type { Product } from "@/db/schema";
import { formatPrice, ratingToStars } from "@/lib/format";

export default function ProductCard({
  product,
  priority = false,
}: {
  product: Product;
  priority?: boolean;
}) {
  const [primary, secondary] = product.images;

  return (
    <Link href={`/product/${product.slug}`} className="group block">
      <div className="relative aspect-[3/4] w-full overflow-hidden bg-shell">
        <Image
          src={primary}
          alt={product.name}
          fill
          priority={priority}
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
          className="object-cover transition-opacity duration-700 group-hover:opacity-0"
        />
        {secondary && (
          <Image
            src={secondary}
            alt={`${product.name} detail`}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            className="scale-105 object-cover opacity-0 transition-all duration-700 group-hover:opacity-100"
          />
        )}

        <div className="pointer-events-none absolute left-0 top-0 flex flex-col items-start gap-2 p-3">
          {product.isNew && (
            <span className="label-xs bg-bone px-2 py-1 text-ink">New</span>
          )}
          {product.badge && (
            <span className="label-xs bg-ink px-2 py-1 text-bone">{product.badge}</span>
          )}
          {product.compareAtCents && product.compareAtCents > product.priceCents && (
            <span className="label-xs bg-henna px-2 py-1 text-bone">
              −{Math.round(100 - (product.priceCents / product.compareAtCents) * 100)}%
            </span>
          )}
        </div>

        {product.stock < 80 && (
          <span className="label-xs absolute bottom-3 left-3 bg-bone/90 px-2 py-1 text-graphite">
            Only {product.stock} left
          </span>
        )}
      </div>

      <div className="mt-4 flex items-start justify-between gap-4">
        <div>
          <h3 className="text-sm font-medium tracking-tight text-ink">{product.name}</h3>
          <p className="mt-1 text-xs text-stone">{product.tagline}</p>
          <div className="mt-2 flex items-center gap-2">
            <span
              aria-hidden
              className="h-2.5 w-2.5 rounded-full border border-ink/20"
              style={{ backgroundColor: product.colorHex }}
            />
            <span className="text-[11px] text-stone">{product.colorName}</span>
            <span className="text-[11px] text-stone/60">·</span>
            <span className="text-[11px] text-stone/80">{ratingToStars(product.rating)}</span>
          </div>
        </div>
        <div className="shrink-0 text-right">
          <p className="text-sm text-ink">{formatPrice(product.priceCents)}</p>
          {product.compareAtCents && product.compareAtCents > product.priceCents && (
            <p className="text-[11px] text-stone line-through">
              {formatPrice(product.compareAtCents)}
            </p>
          )}
        </div>
      </div>
    </Link>
  );
}
