"use client";

import { useEffect, useState } from "react";

export default function FloatingActions() {
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 250) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const openWhatsApp = () => {
    const phone = "919842019780"; // Tushar Hosiery Tiruppur line
    const text = encodeURIComponent(
      "Hello Tushar Hosiery! I am looking for clothing & hosiery collections from your Tiruppur mill.",
    );
    window.open(`https://wa.me/${phone}?text=${text}`, "_blank");
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-center gap-3">
      {/* Scroll to top button (yellow circle with up arrow, exactly like screenshot) */}
      <button
        type="button"
        onClick={scrollToTop}
        aria-label="Scroll to top"
        className={`flex h-11 w-11 items-center justify-center rounded-full bg-[#f2b842] text-black shadow-lg transition-all duration-300 hover:bg-[#ffc85a] hover:scale-105 active:scale-95 ${
          showScrollTop
            ? "translate-y-0 opacity-100"
            : "pointer-events-none translate-y-3 opacity-0"
        }`}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="18"
          height="18"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="m18 15-6-6-6 6" />
        </svg>
      </button>

      {/* WhatsApp chat button (green circle with whatsapp icon, exactly like screenshot) */}
      <div className="relative">
        {chatOpen && (
          <div className="absolute bottom-14 right-0 w-72 rounded-2xl border border-stone-200 bg-white p-4 text-ink shadow-2xl animate-fade">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-xs font-semibold uppercase tracking-wider text-stone-800">
                  Tushar Hosiery Concierge
                </span>
              </div>
              <button
                type="button"
                onClick={() => setChatOpen(false)}
                className="text-stone-400 hover:text-stone-700 text-xs"
              >
                ✕
              </button>
            </div>
            <p className="mt-3 text-xs leading-relaxed text-stone-600">
              Need assistance with sizing, fabrics or bulk mill orders? Connect directly with our
              Tiruppur team.
            </p>
            <button
              type="button"
              onClick={openWhatsApp}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-[#25D366] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#20ba5a] transition-colors"
            >
              Start WhatsApp Chat
            </button>
          </div>
        )}

        <button
          type="button"
          onClick={() => setChatOpen((prev) => !prev)}
          aria-label="Contact on WhatsApp"
          className="flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-xl transition-all duration-300 hover:bg-[#22bf5b] hover:scale-105 active:scale-95"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="28"
            height="28"
            viewBox="0 0 24 24"
            fill="currentColor"
          >
            <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.711 2.598 2.664-.698c.969.586 1.777.818 2.796.818 3.179 0 5.767-2.587 5.767-5.766.001-3.181-2.587-5.767-5.767-5.767zm7.426 5.766c0 4.098-3.333 7.427-7.426 7.427-1.309 0-2.348-.35-3.376-.879l-4.655 1.22 1.246-4.545c-.628-1.077-.962-2.143-.962-3.223 0-4.098 3.333-7.427 7.747-7.427 4.094 0 7.426 3.333 7.426 7.427zm-3.313 3.655c-.179-.089-1.062-.524-1.226-.583-.165-.06-.285-.089-.405.089-.12.18-.465.583-.57.703-.105.12-.21.135-.39.045-.18-.089-.759-.28-1.446-.892-.534-.476-.895-1.064-1-1.244-.105-.18-.011-.277.079-.366.081-.081.18-.21.27-.315.09-.105.12-.18.18-.3.06-.12.03-.225-.015-.315-.045-.09-.405-.975-.555-1.335-.146-.35-.295-.302-.405-.308l-.345-.006c-.12 0-.315.045-.48.225-.165.18-.63.615-.63 1.5s.645 1.74 1.735 1.74c1.09 0 2.21-1.045 2.21-1.045s.165-.075.255-.045.675.315.795.375.18.09.21.135c.03.045.03.255-.15.435z" />
          </svg>
        </button>
      </div>
    </div>
  );
}
