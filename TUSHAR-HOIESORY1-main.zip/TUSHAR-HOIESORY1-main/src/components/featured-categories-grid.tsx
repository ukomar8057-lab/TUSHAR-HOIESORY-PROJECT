"use client";

import Link from "next/link";
import { useState } from "react";

export type CategoryTile = {
  id: string;
  name: string;
  stylesCount: string;
  icon: string;
  href: string;
  badge?: string;
  description: string;
};

const CATEGORIES: CategoryTile[] = [
  {
    id: "tshirts",
    name: "T-Shirts",
    stylesCount: "120+ Styles",
    icon: "👕",
    href: "/shop?category=tshirts",
    description: "Heavyweight combed cotton, 260 GSM single jersey, boxy & classic cuts.",
  },
  {
    id: "shirts",
    name: "Shirts",
    stylesCount: "85+ Styles",
    icon: "👔",
    href: "/shop?category=shirts",
    description: "Fine-gauge knit oxford shirts, structured collar, mother-of-pearl buttons.",
  },
  {
    id: "jeans",
    name: "Jeans",
    stylesCount: "64+ Styles",
    icon: "👖",
    href: "/shop?category=jeans",
    description: "13.5oz vintage ring-spun selvedge denim, ozone-washed indigo.",
  },
  {
    id: "hoodies",
    name: "Hoodies",
    stylesCount: "48+ Styles",
    icon: "🧥",
    href: "/shop?category=hoodies",
    description: "420 GSM heavy loopback French terry, double-layer structured hood.",
  },
  {
    id: "trackpants",
    name: "Track Pants",
    stylesCount: "56+ Styles",
    icon: "🩳",
    href: "/shop?category=trackpants",
    description: "Tapered French terry joggers, clean waistband with zip pockets.",
  },
  {
    id: "jackets",
    name: "Jackets",
    stylesCount: "40+ Styles",
    icon: "🥼",
    href: "/shop?category=jackets",
    description: "Heritage chore jackets, utility overshirts with solid brass hardware.",
  },
  {
    id: "boys",
    name: "Boys Outfit",
    stylesCount: "110+ Styles",
    icon: "👦",
    href: "/shop?audience=boys",
    description: "Durable cotton tees, denim & comfortable joggers designed for active boys.",
  },
  {
    id: "girls",
    name: "Girls Outfit",
    stylesCount: "95+ Styles",
    icon: "👧",
    href: "/shop?audience=girls",
    description: "Charming dresses, cotton tops, co-ord sets & casual outfits for girls.",
  },
  {
    id: "kidswear",
    name: "Kids Wear",
    stylesCount: "75+ Styles",
    icon: "🧸",
    href: "/shop?audience=kids",
    description: "GOTS-certified organic cotton soft-knit clothing sets for sensitive skin.",
  },
  {
    id: "mens",
    name: "Men's Collection",
    stylesCount: "300+ Styles",
    icon: "🤵",
    href: "/shop?audience=men",
    description: "Full wardrobe: heavy jersey tees, oxford shirts, selvedge denim & jackets.",
  },
];

export default function FeaturedCategoriesGrid() {
  const [selectedId, setSelectedId] = useState<string>("shirts");

  const selectedCategory = CATEGORIES.find((c) => c.id === selectedId) || CATEGORIES[1];

  return (
    <section className="relative overflow-hidden border-y border-ink/10 bg-bone py-20 text-ink sm:py-28">
      <div className="relative mx-auto max-w-[1600px] px-4 sm:px-8">
        {/* Section Header */}
        <div className="text-center">
          <p className="label-xs text-stone">Explore Our Lineup</p>
          <h2 className="font-display text-4xl tracking-tight text-ink sm:text-5xl lg:text-6xl mt-2">
            Featured{" "}
            <span className="italic text-henna font-serif transition-colors duration-300">
              Categories
            </span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-xs sm:text-sm text-graphite font-light leading-relaxed">
            Explore our handpicked apparel collections crafted with premium combed cotton and impeccable attention
            to detail.
          </p>
        </div>

        {/* 10-Item Categories Grid */}
        <div className="mt-14 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 sm:gap-4 lg:gap-5">
          {CATEGORIES.map((category) => {
            const isSelected = selectedId === category.id;

            return (
              <button
                key={category.id}
                type="button"
                onClick={() => setSelectedId(category.id)}
                className={`group relative flex flex-col items-center justify-center rounded-2xl p-5 sm:p-6 transition-all duration-300 text-center ${
                  isSelected
                    ? "bg-white border-2 border-ink shadow-md"
                    : "bg-white/80 border border-ink/10 hover:border-ink/30 hover:bg-white"
                }`}
              >
                {/* Circle indicator on top-right */}
                {isSelected && (
                  <span
                    aria-hidden
                    className="absolute right-3 top-3 h-3.5 w-3.5 rounded-full border border-ink bg-ink"
                  />
                )}

                {/* Inner Icon Squircle */}
                <div
                  className={`flex h-14 w-14 sm:h-16 sm:w-16 items-center justify-center rounded-2xl border text-3xl sm:text-4xl shadow-sm transition-transform duration-300 group-hover:scale-110 ${
                    isSelected
                      ? "border-ink bg-ink text-bone"
                      : "border-ink/10 bg-shell/60 text-ink"
                  }`}
                >
                  <span role="img" aria-label={category.name}>
                    {category.icon}
                  </span>
                </div>

                {/* Category Title */}
                <h3
                  className={`mt-4 text-sm sm:text-base font-semibold tracking-wide transition-colors ${
                    isSelected ? "text-ink font-bold" : "text-ink group-hover:text-henna"
                  }`}
                >
                  {category.name}
                </h3>

                {/* Styles Count */}
                <p className="mt-1 text-xs text-stone font-normal">
                  {category.stylesCount}
                </p>
              </button>
            );
          })}
        </div>

        {/* Selected Category Action Bar */}
        <div className="mt-10 rounded-2xl border border-ink/10 bg-white p-5 sm:p-6 shadow-sm">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-ink text-bone text-2xl">
                {selectedCategory.icon}
              </div>
              <div>
                <div className="flex items-center gap-3">
                  <h4 className="text-base font-semibold text-ink">
                    {selectedCategory.name}
                  </h4>
                  <span className="label-xs rounded bg-henna/15 px-2.5 py-1 text-henna font-medium">
                    {selectedCategory.stylesCount}
                  </span>
                </div>
                <p className="mt-1 text-xs text-graphite">
                  {selectedCategory.description}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <Link
                href={selectedCategory.href}
                className="label-sm inline-flex items-center gap-2 rounded-lg bg-ink px-6 py-3 font-medium text-bone transition-all hover:bg-henna"
              >
                Explore {selectedCategory.name} →
              </Link>
              <Link
                href="/shop"
                className="label-sm inline-flex items-center gap-2 rounded-lg border border-ink/20 px-5 py-3 text-ink transition-colors hover:bg-ink hover:text-bone"
              >
                All Apparel
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
