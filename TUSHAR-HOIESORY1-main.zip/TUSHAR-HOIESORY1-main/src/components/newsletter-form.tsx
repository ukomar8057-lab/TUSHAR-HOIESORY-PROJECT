"use client";

import { useActionState } from "react";
import { subscribeAction } from "@/app/actions";
import { initialActionState } from "@/lib/action-state";

export default function NewsletterForm({ tone = "light" }: { tone?: "light" | "dark" }) {
  const [state, formAction, pending] = useActionState(subscribeAction, initialActionState);
  const dark = tone === "dark";

  return (
    <div className="mt-4">
      <form action={formAction} className="flex items-end gap-3">
        <input
          type="email"
          name="email"
          required
          placeholder="your@email.com"
          className={`w-full border-b bg-transparent pb-2 text-sm outline-none transition-colors ${
            dark
              ? "border-bone/30 text-bone placeholder:text-bone/40 focus:border-bone"
              : "border-ink/25 text-ink placeholder:text-stone/70 focus:border-ink"
          }`}
        />
        <button
          type="submit"
          disabled={pending}
          className={`label-xs shrink-0 px-4 py-2 transition-colors disabled:opacity-50 ${
            dark ? "bg-bone text-ink hover:bg-henna hover:text-bone" : "bg-ink text-bone hover:bg-henna"
          }`}
        >
          {pending ? "…" : "Join"}
        </button>
      </form>
      {state.message && (
        <p className={`mt-3 text-xs ${state.ok ? (dark ? "text-bone/80" : "text-moss") : "text-henna"}`}>
          {state.message}
        </p>
      )}
    </div>
  );
}
