"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useCallback } from "react";
import type { Collection } from "@/db/schema";
import { AUDIENCE_LABELS, CATEGORY_LABELS, SORT_OPTIONS } from "@/lib/constants";

type Props = {
  collections: Collection[];
  active: { category?: string; audience?: string; collection?: string; sort?: string; q?: string };
  total: number;
};

export default function FilterBar({ collections, active, total }: Props) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const buildHref = useCallback(
    (key: string, value?: string) => {
      const params = new URLSearchParams(searchParams.toString());
      if (!value || params.get(key) === value) {
        params.delete(key);
      } else {
        params.set(key, value);
      }
      const query = params.toString();
      return query ? `/shop?${query}` : "/shop";
    },
    [searchParams],
  );

  const goTo = (key: string, value?: string) => router.push(buildHref(key, value));

  const hasFilters = Boolean(active.category || active.audience || active.collection || active.q);

  return (
    <div className="sticky top-[92px] z-30 border-b border-ink/10 bg-bone/95 backdrop-blur-md lg:top-[144px]">
      <div className="mx-auto max-w-[1600px] px-4 sm:px-8">
        <div className="no-scrollbar flex items-center gap-5 overflow-x-auto py-4">
          <div className="flex shrink-0 items-center gap-2">
            <span className="label-xs text-stone">Type</span>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => goTo("category")}
                className={`label-xs px-3 py-2 transition-colors ${
                  !active.category ? "bg-ink text-bone" : "text-graphite hover:text-ink"
                }`}
              >
                All
              </button>
              {Object.entries(CATEGORY_LABELS).map(([value, label]) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => goTo("category", value)}
                  className={`label-xs whitespace-nowrap px-3 py-2 transition-colors ${
                    active.category === value ? "bg-ink text-bone" : "text-graphite hover:text-ink"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <span className="h-6 w-px shrink-0 bg-ink/15" />

          <div className="flex shrink-0 items-center gap-2">
            <span className="label-xs text-stone">For</span>
            <div className="flex items-center gap-1">
              {Object.entries(AUDIENCE_LABELS).map(([value, label]) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => goTo("audience", value)}
                  className={`label-xs whitespace-nowrap px-3 py-2 transition-colors ${
                    active.audience === value ? "bg-ink text-bone" : "text-graphite hover:text-ink"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <span className="h-6 w-px shrink-0 bg-ink/15" />

          <label className="flex shrink-0 items-center gap-2">
            <span className="label-xs text-stone">Collection</span>
            <select
              value={active.collection ?? ""}
              onChange={(event) => goTo("collection", event.target.value || undefined)}
              className="label-xs border border-ink/20 bg-transparent px-3 py-2 text-ink outline-none focus:border-ink"
            >
              <option value="">All</option>
              {collections.map((collection) => (
                <option key={collection.slug} value={collection.slug}>
                  {collection.title}
                </option>
              ))}
            </select>
          </label>

          <label className="ml-auto flex shrink-0 items-center gap-2">
            <span className="label-xs text-stone">Sort</span>
            <select
              value={active.sort ?? "featured"}
              onChange={(event) => goTo("sort", event.target.value === "featured" ? undefined : event.target.value)}
              className="label-xs border border-ink/20 bg-transparent px-3 py-2 text-ink outline-none focus:border-ink"
            >
              {SORT_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-ink/10 py-3">
          <p className="label-xs text-stone">
            {total} {total === 1 ? "piece" : "pieces"}
            {active.q ? ` for “${active.q}”` : ""}
          </p>
          {hasFilters && (
            <button
              type="button"
              onClick={() => router.push("/shop")}
              className="label-xs text-henna link-underline"
            >
              Clear filters
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
