"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import type { Collection } from "@/db/schema";
import { LOGO_DATA_URL } from "@/lib/logo";

type Props = {
  cartCount: number;
  collections: Collection[];
};

const primaryLinks = [
  { href: "/shop", label: "Shop All" },
  { href: "/shop?audience=men", label: "Men" },
  { href: "/shop?audience=boys", label: "Boys" },
  { href: "/shop?audience=girls", label: "Girls" },
  { href: "/shop?audience=kids", label: "Kids" },
  { href: "/about", label: "The Mill" },
];

export default function SiteHeader({ cartCount, collections }: Props) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const pathname = usePathname();

  useEffect(() => {
    setMenuOpen(false);
    setSearchOpen(false);
  }, [pathname]);

  return (
    <header className="sticky top-0 z-50 bg-bone/95 backdrop-blur-md">
      <div className="overflow-hidden border-b border-ink/10 bg-ink text-bone">
        <div className="flex w-max animate-marquee whitespace-nowrap py-2">
          {[0, 1].map((copy) => (
            <div key={copy} className="flex shrink-0 items-center gap-10 pr-10">
              <span className="label-xs">Free shipping over ₹3,000</span>
              <span className="label-xs opacity-60">/</span>
              <span className="label-xs">Knitted in Tiruppur since 1978</span>
              <span className="label-xs opacity-60">/</span>
              <span className="label-xs">30-day returns, no questions</span>
              <span className="label-xs opacity-60">/</span>
              <span className="label-xs">New: Winter Weight has landed</span>
              <span className="label-xs opacity-60">/</span>
            </div>
          ))}
        </div>
      </div>

      <div className="border-b border-ink/10">
        <div className="mx-auto grid h-[4.75rem] max-w-[1600px] grid-cols-[1fr_auto_1fr] items-center px-4 sm:h-[5.5rem] sm:px-8">
          <div className="flex items-center gap-6">
            <button
              type="button"
              onClick={() => setMenuOpen((open) => !open)}
              aria-label="Toggle menu"
              aria-expanded={menuOpen}
              className="flex h-9 w-9 flex-col items-start justify-center gap-[5px] lg:hidden"
            >
              <span
                className={`h-px w-6 bg-ink transition-transform duration-300 ${menuOpen ? "translate-y-[3px] rotate-45" : ""}`}
              />
              <span
                className={`h-px w-6 bg-ink transition-transform duration-300 ${menuOpen ? "-translate-y-[3px] -rotate-45" : ""}`}
              />
            </button>

            <nav className="hidden items-center gap-7 lg:flex">
              {primaryLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="label-sm link-underline text-graphite hover:text-ink"
                >
                  {link.label}
                </Link>
              ))}
            </nav>
          </div>

          <Link href="/" className="flex flex-col items-center leading-none">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={LOGO_DATA_URL}
              alt="Tushar Hosiery logo"
              width={32}
              height={32}
              className="mb-1 h-7 w-7 rounded-full sm:h-8 sm:w-8"
            />
            <span className="font-display text-[1.35rem] tracking-[0.34em] text-ink sm:text-[1.6rem]">
              TUSHAR
            </span>
            <span className="label-xs mt-1 text-stone">Hosiery · Est. 1978</span>
          </Link>

          <div className="flex items-center justify-end gap-5">
            <button
              type="button"
              onClick={() => setSearchOpen((open) => !open)}
              className="label-sm text-graphite hover:text-ink"
              aria-label="Search"
            >
              Search
            </button>
            <Link href="/cart" className="label-sm text-graphite hover:text-ink">
              Bag{cartCount > 0 ? ` (${cartCount})` : ""}
            </Link>
          </div>
        </div>

        {searchOpen && (
          <div className="border-t border-ink/10 bg-shell/60">
            <form action="/shop" className="mx-auto flex max-w-[1600px] items-center gap-4 px-4 py-5 sm:px-8">
              <input
                autoFocus
                name="q"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search t-shirts, shirts, jeans, hoodies, jackets…"
                className="display-md w-full border-b border-ink/25 bg-transparent pb-2 outline-none placeholder:text-stone/70 focus:border-ink"
              />
              <button type="submit" className="label-sm shrink-0 bg-ink px-6 py-3 text-bone hover:bg-henna">
                Go
              </button>
            </form>
          </div>
        )}
      </div>

      <div className="hidden border-b border-ink/10 bg-bone lg:block">
        <div className="mx-auto flex max-w-[1600px] items-center gap-8 px-8 py-3">
          <span className="label-xs text-stone">Collections</span>
          {collections.map((collection) => (
            <Link
              key={collection.slug}
              href={`/collections/${collection.slug}`}
              className="label-xs link-underline text-graphite hover:text-ink"
            >
              {collection.title}
            </Link>
          ))}
          <Link href="/shop?sort=new" className="label-xs ml-auto text-henna link-underline">
            New Arrivals
          </Link>
        </div>
      </div>

      {menuOpen && (
        <div className="animate-fade border-b border-ink/10 bg-bone lg:hidden">
          <nav className="mx-auto flex max-w-[1600px] flex-col divide-y divide-ink/10 px-4 sm:px-8">
            {primaryLinks.map((link) => (
              <Link key={link.href} href={link.href} className="display-md py-4 text-ink">
                {link.label}
              </Link>
            ))}
            <div className="flex flex-wrap gap-x-5 gap-y-3 py-5">
              {collections.map((collection) => (
                <Link
                  key={collection.slug}
                  href={`/collections/${collection.slug}`}
                  className="label-xs text-graphite"
                >
                  {collection.title}
                </Link>
              ))}
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
