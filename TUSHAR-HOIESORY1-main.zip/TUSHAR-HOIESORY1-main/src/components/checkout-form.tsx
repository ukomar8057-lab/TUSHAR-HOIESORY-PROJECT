"use client";

import { useActionState, useState } from "react";
import { placeOrderAction } from "@/app/actions";
import { initialActionState } from "@/lib/action-state";
import { expressShippingCents, formatPrice, standardShippingCents } from "@/lib/format";

export default function CheckoutForm({
  subtotalCents,
  freeShippingUnlocked,
}: {
  subtotalCents: number;
  freeShippingUnlocked: boolean;
}) {
  const [state, formAction, pending] = useActionState(placeOrderAction, initialActionState);
  const [shippingMethod, setShippingMethod] = useState<"standard" | "express">("standard");

  const standard = freeShippingUnlocked ? 0 : standardShippingCents();
  const shipping = shippingMethod === "express" ? expressShippingCents() : standard;
  const total = subtotalCents + shipping;

  const fieldClass =
    "w-full border border-ink/20 bg-transparent px-4 py-4 text-sm text-ink outline-none transition-colors placeholder:text-stone/60 focus:border-ink";

  return (
    <form action={formAction} className="mt-12">
      <input type="hidden" name="shippingMethod" value={shippingMethod} />

      <section>
        <h2 className="display-md">Contact</h2>
        <div className="mt-6 grid gap-4">
          <input type="email" name="email" required placeholder="Email address" className={fieldClass} />
          <input
            type="tel"
            name="phone"
            required
            inputMode="tel"
            autoComplete="tel"
            placeholder="Mobile number (for delivery updates)"
            className={fieldClass}
          />
        </div>
      </section>

      <section className="mt-14">
        <h2 className="display-md">Delivery</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <input name="fullName" required placeholder="Full name" className={`${fieldClass} sm:col-span-2`} />
          <input name="address" required placeholder="Street address" className={`${fieldClass} sm:col-span-2`} />
          <input name="city" required placeholder="City" className={fieldClass} />
          <input name="postalCode" required placeholder="Postal code" className={fieldClass} />
          <select name="country" required defaultValue="India" className={`${fieldClass} sm:col-span-2`}>
            <option value="India">India</option>
            <option value="United Kingdom">United Kingdom</option>
            <option value="United States">United States</option>
            <option value="United Arab Emirates">United Arab Emirates</option>
            <option value="Singapore">Singapore</option>
          </select>
        </div>
      </section>

      <section className="mt-14">
        <h2 className="display-md">Shipping method</h2>
        <div className="mt-6 grid gap-3">
          {[
            {
              value: "standard" as const,
              title: "Standard",
              detail: "4–6 working days · Tiruppur to your door",
              price: standard,
            },
            {
              value: "express" as const,
              title: "Express",
              detail: "2–3 working days · tracked priority",
              price: expressShippingCents(),
            },
          ].map((option) => (
            <button
              key={option.value}
              type="button"
              onClick={() => setShippingMethod(option.value)}
              className={`flex items-center justify-between border px-5 py-5 text-left transition-colors ${
                shippingMethod === option.value
                  ? "border-ink bg-ink text-bone"
                  : "border-ink/20 hover:border-ink"
              }`}
            >
              <span>
                <span className="label-xs block">{option.title}</span>
                <span
                  className={`mt-2 block text-[11px] ${shippingMethod === option.value ? "text-bone/70" : "text-stone"}`}
                >
                  {option.detail}
                </span>
              </span>
              <span className="text-sm">{option.price === 0 ? "Free" : formatPrice(option.price)}</span>
            </button>
          ))}
        </div>
      </section>

      <section className="mt-14">
        <h2 className="display-md">Payment</h2>
        <p className="mt-4 text-xs leading-relaxed text-stone">
          This is a demonstration store — no payment is captured. Place the order to see a live
          confirmation generated from the database.
        </p>
      </section>

      <div className="mt-12 border-t border-ink/15 pt-8">
        <div className="flex items-baseline justify-between">
          <span className="label-xs text-graphite">Total payable</span>
          <span className="font-display text-4xl">{formatPrice(total)}</span>
        </div>
        <button
          type="submit"
          disabled={pending}
          className="label-sm mt-6 w-full bg-ink px-8 py-5 text-bone transition-colors hover:bg-henna disabled:opacity-60"
        >
          {pending ? "Placing order…" : "Place order"}
        </button>
        {state.message && (
          <p className="mt-4 border border-henna/40 bg-henna/10 px-4 py-3 text-xs text-henna">
            {state.message}
          </p>
        )}
        <p className="mt-4 text-center text-[11px] text-stone">
          By placing this order you agree to our terms and 30-day return policy.
        </p>
      </div>
    </form>
  );
}
