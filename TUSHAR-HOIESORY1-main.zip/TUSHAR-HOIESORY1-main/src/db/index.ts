import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

/**
 * Single database connection for the whole site: Supabase Postgres.
 * Set DATABASE_URL in .env.local (Supabase -> Connect -> Transaction pooler).
 */
function buildConnectionString(): string {
  const raw = process.env.DATABASE_URL;
  if (!raw) {
    throw new Error(
      "DATABASE_URL is missing. Add your Supabase connection string to .env.local " +
        "(Supabase Dashboard -> Connect -> Transaction pooler) and restart the server.",
    );
  }
  // `pg` lets an `sslmode=` query param override our ssl option, so remove it
  // and control SSL ourselves below.
  try {
    const url = new URL(raw);
    url.searchParams.delete("sslmode");
    return url.toString();
  } catch {
    return raw;
  }
}

const globalForDb = globalThis as typeof globalThis & {
  __tusharPgPool?: Pool;
};

function createPool(): Pool {
  const connectionString = buildConnectionString();
  const isLocal = /@(localhost|127\.0\.0\.1)/.test(connectionString);
  return new Pool({
    connectionString,
    max: 5,
    idleTimeoutMillis: 20_000,
    connectionTimeoutMillis: 10_000,
    ssl: isLocal ? false : { rejectUnauthorized: false },
  });
}

// Created lazily so `next build` does not need a database connection.
export function getPool(): Pool {
  if (!globalForDb.__tusharPgPool) {
    globalForDb.__tusharPgPool = createPool();
  }
  return globalForDb.__tusharPgPool;
}

type Db = ReturnType<typeof drizzle>;

function getDb(): Db {
  return drizzle(getPool());
}

// `db` behaves like a normal drizzle instance but connects on first use.
export const db: Db = new Proxy({} as Db, {
  get(_target, prop) {
    const real = getDb() as unknown as Record<string | symbol, unknown>;
    const value = real[prop];
    return typeof value === "function" ? (value as Function).bind(real) : value;
  },
});
