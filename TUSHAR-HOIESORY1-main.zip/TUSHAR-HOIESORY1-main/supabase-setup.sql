-- ====================================================================
-- TUSHAR HOSIERY - SUPABASE SETUP (run ONCE on a NEW Supabase project)
--
-- How to run: Supabase Dashboard -> SQL Editor -> New query ->
-- paste this whole file -> click RUN. Safe to run again (re-runnable).
--
-- What it does:
--   1. Creates all tables
--   2. Creates the `profiles` table + admin role (admin email below)
--   3. Turns ON Row Level Security (RLS) on every table
--   4. Creates the public `product-images` Storage bucket (admin-only upload)
--   5. Loads your starting collections and products
--
-- Admin email: ukomar8057@gmail.com
-- After running this, create that user in Dashboard -> Authentication -> Users
-- -> "Add user" (tick "Auto Confirm User"). That user becomes the admin.
-- ====================================================================

-- --------------------------------------------------------------------
-- 1-5. Tables
-- --------------------------------------------------------------------
-- 1. Create Products Table
CREATE TABLE IF NOT EXISTS public.products (
  id serial PRIMARY KEY,
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  tagline text NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  audience text NOT NULL,
  collection_slug text NOT NULL,
  price_cents integer NOT NULL,
  compare_at_cents integer,
  color_name text NOT NULL,
  color_hex text NOT NULL,
  fabric text NOT NULL,
  denier text,
  badge text,
  images jsonb NOT NULL,
  sizes jsonb NOT NULL,
  details jsonb NOT NULL,
  rating integer NOT NULL DEFAULT 48,
  review_count integer NOT NULL DEFAULT 0,
  stock integer NOT NULL DEFAULT 40,
  is_featured boolean NOT NULL DEFAULT false,
  is_new boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 2. Create Collections Table
CREATE TABLE IF NOT EXISTS public.collections (
  id serial PRIMARY KEY,
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  kicker text NOT NULL,
  description text NOT NULL,
  image text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0
);

-- 3. Create Carts & Cart Items Table
CREATE TABLE IF NOT EXISTS public.carts (
  id serial PRIMARY KEY,
  token text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.cart_items (
  id serial PRIMARY KEY,
  cart_id integer NOT NULL REFERENCES public.carts(id) ON DELETE CASCADE,
  product_id integer NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  size text NOT NULL,
  quantity integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT cart_items_unique_line UNIQUE (cart_id, product_id, size)
);

-- 4. Create Orders & Order Items Table
CREATE TABLE IF NOT EXISTS public.orders (
  id serial PRIMARY KEY,
  order_number text NOT NULL UNIQUE,
  email text NOT NULL,
  full_name text NOT NULL,
  address text NOT NULL,
  city text NOT NULL,
  postal_code text NOT NULL,
  country text NOT NULL,
  shipping_method text NOT NULL,
  subtotal_cents integer NOT NULL,
  shipping_cents integer NOT NULL,
  total_cents integer NOT NULL,
  status text NOT NULL DEFAULT 'confirmed',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.order_items (
  id serial PRIMARY KEY,
  order_id integer NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id integer NOT NULL,
  name text NOT NULL,
  slug text NOT NULL,
  image text NOT NULL,
  size text NOT NULL,
  quantity integer NOT NULL,
  unit_price_cents integer NOT NULL
);

-- 5. Create Subscribers Table
CREATE TABLE IF NOT EXISTS public.subscribers (
  id serial PRIMARY KEY,
  email text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- --------------------------------------------------------------------
-- 6. Profiles + admin role
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Every new auth user gets a profile. Only the admin email becomes 'admin'.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, role)
  VALUES (
    NEW.id,
    NEW.email,
    CASE WHEN lower(NEW.email) = 'ukomar8057@gmail.com' THEN 'admin' ELSE 'user' END
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- If the admin user already exists, make sure it has a profile with role admin.
INSERT INTO public.profiles (id, email, role)
SELECT id, email, CASE WHEN lower(email) = 'ukomar8057@gmail.com' THEN 'admin' ELSE 'user' END
FROM auth.users
ON CONFLICT (id) DO NOTHING;

UPDATE public.profiles SET role = 'admin' WHERE lower(email) = 'ukomar8057@gmail.com';

-- Helper used by every admin policy
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'
  );
$$;

-- --------------------------------------------------------------------
-- 7. Row Level Security
-- The website server talks to the database with the `postgres` role (it
-- bypasses RLS) and checks admin login in code. RLS protects everything
-- reachable through the public Supabase API / anon key.
-- --------------------------------------------------------------------
ALTER TABLE public.products     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.collections  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.carts        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cart_items   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscribers  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles     ENABLE ROW LEVEL SECURITY;

-- Public catalog: anyone can read, only admin can change
DROP POLICY IF EXISTS "catalog read products" ON public.products;
CREATE POLICY "catalog read products" ON public.products
  FOR SELECT USING (true);
DROP POLICY IF EXISTS "admin write products" ON public.products;
CREATE POLICY "admin write products" ON public.products
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "catalog read collections" ON public.collections;
CREATE POLICY "catalog read collections" ON public.collections
  FOR SELECT USING (true);
DROP POLICY IF EXISTS "admin write collections" ON public.collections;
CREATE POLICY "admin write collections" ON public.collections
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Private data: no public access at all. Admin can read/update through the API.
DROP POLICY IF EXISTS "admin all orders" ON public.orders;
CREATE POLICY "admin all orders" ON public.orders
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "admin all order_items" ON public.order_items;
CREATE POLICY "admin all order_items" ON public.order_items
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "admin all subscribers" ON public.subscribers;
CREATE POLICY "admin all subscribers" ON public.subscribers
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "admin all carts" ON public.carts;
CREATE POLICY "admin all carts" ON public.carts
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "admin all cart_items" ON public.cart_items;
CREATE POLICY "admin all cart_items" ON public.cart_items
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Profiles: a user can read only their own row. Nobody can edit roles from the API.
DROP POLICY IF EXISTS "read own profile" ON public.profiles;
CREATE POLICY "read own profile" ON public.profiles
  FOR SELECT TO authenticated USING (id = auth.uid() OR public.is_admin());

-- --------------------------------------------------------------------
-- 8. Storage bucket for product images (public read, admin-only write)
-- --------------------------------------------------------------------
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'product-images', 'product-images', true, 5242880,
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif']
)
ON CONFLICT (id) DO UPDATE SET
  public = true,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

DROP POLICY IF EXISTS "product images public read" ON storage.objects;
CREATE POLICY "product images public read" ON storage.objects
  FOR SELECT USING (bucket_id = 'product-images');

DROP POLICY IF EXISTS "product images admin insert" ON storage.objects;
CREATE POLICY "product images admin insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'product-images' AND public.is_admin());

DROP POLICY IF EXISTS "product images admin update" ON storage.objects;
CREATE POLICY "product images admin update" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'product-images' AND public.is_admin());

DROP POLICY IF EXISTS "product images admin delete" ON storage.objects;
CREATE POLICY "product images admin delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'product-images' AND public.is_admin());

-- --------------------------------------------------------------------
-- 9. Starting data (collections + products)
-- Insert-only: running this file again never overwrites changes made in the admin panel.
-- --------------------------------------------------------------------
-- 6. Insert Collections Data
INSERT INTO public.collections (slug, title, kicker, description, image, sort_order)
VALUES 
('signature-rib', 'Signature Rib', 'Core Apparel', 'Heavy 3x1 combed cotton tees, polos & structured tops knitted on vintage circular frames for lasting shape.', 'https://images.pexels.com/photos/9775825/pexels-photo-9775825.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800', 1),
('sheer-studio', 'Fine Oxford & Knits', 'Tailored Wear', 'Fine-gauge oxford button-down shirts and woven tops engineered for breathability and crisp silhouette.', 'https://images.pexels.com/photos/9775674/pexels-photo-9775674.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800', 2),
('merino-trail', 'Merino & Sweaters', 'Knitwear', 'Pure merino wool & cotton-blend knitted sweaters, cardigans, and pullovers for effortless layering.', 'https://images.pexels.com/photos/8346261/pexels-photo-8346261.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800', 3),
('winter-weight', 'Winter Weight Fleece', 'Outerwear & Hoodies', '420 GSM heavy loopback French terry hoodies, crewnecks, and rugged heritage utility chore jackets.', 'https://images.pexels.com/photos/28701960/pexels-photo-28701960.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800', 4),
('studio-move', 'Studio Move Joggers', 'Track & Active', 'Tapered French terry track pants, comfortable sweat shorts, and active co-ord sets.', 'https://images.pexels.com/photos/6995892/pexels-photo-6995892.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800', 5)
ON CONFLICT (slug) DO NOTHING;

-- 7. Insert Product Catalog Data (Men, Boys, Girls, Kids Outfits)
INSERT INTO public.products (
  slug, name, tagline, description, category, audience, collection_slug,
  price_cents, color_name, color_hex, fabric, badge, images, sizes, details,
  rating, review_count, stock, is_featured, is_new, sort_order
)
VALUES
-- MEN & UNISEX OUTFITS
(
  'heavyweight-combed-tee', 'Heavyweight Combed Tee', '260 GSM single jersey cotton',
  'Knitted from premium combed long-staple cotton with a ribbed collar that never sags. Dense, structured drape with a velvety hand-feel that softens with every wash.',
  'tshirts', 'men', 'signature-rib', 149000, 'Bone White', '#F2EFE9', '100% long-staple combed cotton, 260 GSM',
  'Bestseller',
  '["https://images.pexels.com/photos/9775825/pexels-photo-9775825.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/13651809/pexels-photo-13651809.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["S", "M", "L", "XL", "XXL"]'::jsonb,
  '["260 GSM heavyweight single jersey", "Reinforced twin-needle collar rib", "Pre-shrunk fabric", "Machine wash cold"]'::jsonb,
  49, 420, 140, true, false, 1
),
(
  'oxford-knit-overshirt', 'Oxford Knitted Shirt', 'Fine-gauge knit structure',
  'A tailored button-up shirt crafted on circular knit looms with a breathable piqué-oxford structure. Moves like knitwear, looks sharp like classic tailoring.',
  'shirts', 'men', 'sheer-studio', 249000, 'Chambray Blue', '#7B96B2', '100% organic cotton piqué-knit',
  'Trending',
  '["https://images.pexels.com/photos/9775674/pexels-photo-9775674.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/7764013/pexels-photo-7764013.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["S", "M", "L", "XL"]'::jsonb,
  '["Mother-of-pearl buttons", "Structured soft collar", "Pre-washed for non-crease feel", "Machine wash 30°C"]'::jsonb,
  48, 310, 95, true, false, 2
),
(
  'selvedge-relaxed-denim', 'Relaxed Indigo Denim', '13.5oz ring-spun denim',
  'Cut in a contemporary relaxed taper from 13.5oz durable indigo cotton. Softened using ozone eco-wash processes for an authentic lived-in feel.',
  'jeans', 'men', 'signature-rib', 329000, 'Vintage Indigo', '#395175', '99% cotton, 1% comfort stretch',
  NULL,
  '["https://images.pexels.com/photos/7764608/pexels-photo-7764608.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/4271568/pexels-photo-4271568.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["30", "32", "34", "36"]'::jsonb,
  '["Custom branded copper hardware", "Deep reinforced pockets", "Chain-stitched hems", "Wash inside out cold"]'::jsonb,
  49, 185, 80, false, false, 3
),
(
  'loopback-fleece-hoodie', 'Heavy Loopback Hoodie', '420 GSM French terry',
  'Crafted from ultra-dense loopback fleece with a structured double-layer hood that stands upright. Tailored kangaroo pocket and heavy 2x2 ribbed side gussets.',
  'hoodies', 'unisex', 'winter-weight', 299000, 'Pitch Black', '#18181A', '100% combed cotton loopback, 420 GSM',
  'Essential',
  '["https://images.pexels.com/photos/28701960/pexels-photo-28701960.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/8346261/pexels-photo-8346261.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["XS", "S", "M", "L", "XL"]'::jsonb,
  '["420 GSM heavyweight loopback", "Seamless clean interior", "Heavy gauge drawstring with dipped metal aglets", "Machine wash gentle"]'::jsonb,
  49, 520, 110, true, false, 4
),
(
  'french-terry-track-pant', 'Tapered Track Pant', 'Comfort stretch with clean lines',
  'Engineered for daily movement. Clean flat-front waistband with internal drawcord, discreet zippered side pockets, and a neat ribbed ankle cuff.',
  'trackpants', 'unisex', 'studio-move', 219000, 'Slate Grey', '#4C5158', '95% cotton terry, 5% elastane',
  NULL,
  '["https://images.pexels.com/photos/6995892/pexels-photo-6995892.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/28701950/pexels-photo-28701950.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["S", "M", "L", "XL"]'::jsonb,
  '["Discreet zip pockets", "Gusseted crotch for mobility", "Ribbed cuff finish", "Machine wash cold"]'::jsonb,
  47, 290, 125, false, false, 5
),
(
  'heritage-mill-jacket', 'Heritage Utility Overshirt Jacket', 'Durable twill with brass closures',
  'Inspired by vintage mill technician overshirts. Heavyweight cotton twill with chest patch pockets and inner pen slot, built to layer through seasons.',
  'jackets', 'men', 'winter-weight', 389000, 'Forest Olive', '#374133', '100% heavyweight cotton twill',
  'Heritage',
  '["https://images.pexels.com/photos/9604298/pexels-photo-9604298.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/29197620/pexels-photo-29197620.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["S", "M", "L", "XL"]'::jsonb,
  '["Triple-needle seam construction", "Reinforced elbow patches", "Solid brass buttons", "Dry clean or cold wash"]'::jsonb,
  49, 160, 65, true, false, 6
),
(
  'boxy-raw-hem-tee', 'Boxy Heavy Knit Tee', 'Drop shoulder, relaxed drape',
  'Cut wide and slightly cropped with an open drop-shoulder silhouette. Spun from high-twist carded Indian cotton that drapes with architectural weight.',
  'tshirts', 'unisex', 'signature-rib', 169000, 'Washed Carbon', '#2B2B2D', '100% combed cotton, 280 GSM',
  'New Cut',
  '["https://images.pexels.com/photos/13651809/pexels-photo-13651809.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/9775825/pexels-photo-9775825.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["S", "M", "L", "XL"]'::jsonb,
  '["280 GSM heavyweight jersey", "Deep ribbed neckline", "Dropped shoulders", "Machine wash cold"]'::jsonb,
  48, 195, 90, false, true, 7
),
(
  'linen-blend-resort-shirt', 'Linen-Cotton Camp Shirt', 'Breathable open weave',
  'A warm-weather essential cut with a relaxed camp collar in a slubbed linen-cotton blend. Knitted on low-tension looms for air circulation.',
  'shirts', 'men', 'sheer-studio', 279000, 'Sand Stone', '#C2B69D', '55% Belgian flax linen, 45% organic cotton',
  NULL,
  '["https://images.pexels.com/photos/6616121/pexels-photo-6616121.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/9775674/pexels-photo-9775674.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["S", "M", "L", "XL"]'::jsonb,
  '["Open camp collar", "Slub textured yarn", "Natural shell buttons", "Wash cold, air dry"]'::jsonb,
  49, 140, 75, false, false, 8
),
(
  'vintage-washed-straight-jeans', 'Straight Cut Selvedge Denim', 'Classic mid-rise 5-pocket denim',
  'A timeless straight leg silhouette with red-line selvedge ID at the outseam. Woven slowly on vintage shuttle looms for authentic uneven yarn texture.',
  'jeans', 'unisex', 'signature-rib', 349000, 'Raw Ecru Denim', '#EAE6DB', '100% shuttle-loomed cotton denim, 14oz',
  'Selvedge',
  '["https://images.pexels.com/photos/4271568/pexels-photo-4271568.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/7764608/pexels-photo-7764608.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["28", "30", "32", "34", "36"]'::jsonb,
  '["Red-line shuttle loom selvedge", "Unwashed natural cotton ecru", "Copper rivet reinforcements", "Cold soak recommended"]'::jsonb,
  49, 215, 60, false, true, 9
),
(
  'merino-cable-knit-sweater', 'Merino Cable-Knit Sweater', 'Plush 7-gauge merino knitwear',
  'Spun from 100% Australian extra-fine merino wool in a heavy heritage cable pattern. Warm, soft, and breathable for winter months.',
  'sweaters', 'men', 'merino-trail', 399000, 'Oatmeal Knit', '#D5C8B4', '100% extra-fine merino wool',
  'Warmth',
  '["https://images.pexels.com/photos/8346261/pexels-photo-8346261.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/28701960/pexels-photo-28701960.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["S", "M", "L", "XL"]'::jsonb,
  '["7-gauge cable knit structure", "Ribbed crewneck and cuffs", "Odour-resistant merino yarn", "Hand wash cold"]'::jsonb,
  49, 178, 55, true, false, 10
),

-- BOYS OUTFITS
(
  'boys-graphic-cotton-tee', 'Boys Combed Cotton Crew Tee', 'Soft & durable 220 GSM jersey',
  'Knitted specifically for active boys. Premium combed cotton that stands up to rugged playground wear and frequent washing.',
  'tshirts', 'boys', 'signature-rib', 99000, 'Navy Blue', '#1B2A4A', '100% combed cotton, 220 GSM',
  'Popular',
  '["https://images.pexels.com/photos/1620760/pexels-photo-1620760.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/9775825/pexels-photo-9775825.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["4-5Y", "6-7Y", "8-9Y", "10-12Y", "13-14Y"]'::jsonb,
  '["Double-stitched ribbed crew neck", "Soft skin-friendly cotton", "Color-fast anti-fade dye", "Machine wash warm"]'::jsonb,
  48, 210, 150, true, false, 11
),
(
  'boys-denim-utility-jacket', 'Boys Denim Trucker Jacket', '11oz soft stretch indigo denim',
  'A classic trucker jacket cut for boys with comfort stretch denim, button-up front, and dual buttoned chest pockets.',
  'jackets', 'boys', 'winter-weight', 249000, 'Medium Vintage Wash', '#415A77', '98% cotton, 2% elastane denim',
  'New',
  '["https://images.pexels.com/photos/7764608/pexels-photo-7764608.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/9604298/pexels-photo-9604298.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["6-7Y", "8-9Y", "10-12Y", "13-14Y"]'::jsonb,
  '["Durable copper buttons", "Adjustable waist tabs", "Pre-softened fabric", "Machine wash cold"]'::jsonb,
  49, 145, 90, false, true, 12
),
(
  'boys-fleece-pullover-hoodie', 'Boys Athletic Fleece Hoodie', 'Warm 340 GSM loopback cotton',
  'Plush French terry hoodie with a cozy front pouch pocket and snug ribbed cuffs. Great for sports practice and casual outings.',
  'hoodies', 'boys', 'winter-weight', 189000, 'Heather Grey', '#8D99AE', '90% cotton, 10% polyester loopback terry',
  NULL,
  '["https://images.pexels.com/photos/28701960/pexels-photo-28701960.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/6995892/pexels-photo-6995892.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["4-5Y", "6-7Y", "8-9Y", "10-12Y", "13-14Y"]'::jsonb,
  '["Double-lined hood", "Kangaroo hand pocket", "Ribbed elastic cuffs & hem", "Machine wash cold"]'::jsonb,
  48, 310, 130, false, false, 13
),
(
  'boys-tapered-jogger-pant', 'Boys Cargo Sweat Joggers', 'Comfort waistband with cargo pockets',
  'Tapered joggers featuring an elastic drawcord waistband, deep side pockets, and twin utility cargo pockets for adventure-ready style.',
  'trackpants', 'boys', 'studio-move', 159000, 'Olive Green', '#4F5D48', '95% combed cotton, 5% elastane',
  NULL,
  '["https://images.pexels.com/photos/6995892/pexels-photo-6995892.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/28701950/pexels-photo-28701950.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["4-5Y", "6-7Y", "8-9Y", "10-12Y", "13-14Y"]'::jsonb,
  '["Elastic drawcord waist", "Twin flap cargo pockets", "Stretchy ribbed ankle cuffs", "Machine wash warm"]'::jsonb,
  47, 180, 110, false, false, 14
),
(
  'boys-checkered-flannel-shirt', 'Boys Brushed Cotton Flannel Shirt', 'Soft yarn-dyed plaid check',
  'Brushed on both sides for supreme softness. A classic button-down plaid shirt that layers easily over t-shirts.',
  'shirts', 'boys', 'sheer-studio', 179000, 'Red & Navy Check', '#8B263E', '100% yarn-dyed combed cotton flannel',
  NULL,
  '["https://images.pexels.com/photos/9775674/pexels-photo-9775674.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/7764013/pexels-photo-7764013.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["4-5Y", "6-7Y", "8-9Y", "10-12Y", "13-14Y"]'::jsonb,
  '["Yarn-dyed plaid pattern", "Chest patch pocket", "Pre-shrunk soft hand-feel", "Machine wash cold"]'::jsonb,
  48, 125, 85, false, false, 15
),

-- GIRLS OUTFITS
(
  'girls-ribbed-cotton-frock', 'Girls Tiered Cotton Frock Dress', 'Breathable combed cotton knit dress',
  'A charming tiered dress cut from soft combed cotton jersey with subtle ribbed collar detail and twirl-ready flared skirt.',
  'dresses', 'girls', 'signature-rib', 169000, 'Blush Pink', '#E8B4B8', '100% organic combed cotton jersey',
  'Trending',
  '["https://images.pexels.com/photos/1620760/pexels-photo-1620760.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/9775825/pexels-photo-9775825.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["3-4Y", "5-6Y", "7-8Y", "9-10Y", "11-12Y"]'::jsonb,
  '["Tiered gathered skirt flare", "Soft breathable cotton", "Tagless itch-free back neck", "Machine wash gentle"]'::jsonb,
  49, 260, 120, true, false, 16
),
(
  'girls-pastel-fleece-hoodie', 'Girls Soft Terry Fleece Hoodie', 'Warm loopback fleece hoodie',
  'Relaxed-fit pullover hoodie with a plush brushed interior, relaxed raglan sleeves, and stretchy ribbed trim.',
  'hoodies', 'girls', 'winter-weight', 179000, 'Sage Lavender', '#B8C0E0', '95% combed cotton, 5% elastane terry',
  NULL,
  '["https://images.pexels.com/photos/28701960/pexels-photo-28701960.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/8346261/pexels-photo-8346261.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["4-5Y", "6-7Y", "8-9Y", "10-12Y"]'::jsonb,
  '["Super soft brushed fleece", "Comfortable raglan sleeve cut", "Ribbed sleeve and waist bands", "Machine wash cold"]'::jsonb,
  48, 190, 105, false, false, 17
),
(
  'girls-floral-coord-set', 'Girls Floral Top & Shorts Set', 'Matching 2-piece cotton outfit',
  'A stylish matching co-ord set featuring a ruffle-sleeve cotton top and easy-fit elastic waistband shorts with pockets.',
  'sets', 'girls', 'signature-rib', 199000, 'Sunflower Yellow', '#F4A261', '100% fine combed cotton',
  '2-Piece Set',
  '["https://images.pexels.com/photos/9775825/pexels-photo-9775825.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/1620760/pexels-photo-1620760.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["3-4Y", "5-6Y", "7-8Y", "9-10Y"]'::jsonb,
  '["Set includes top and shorts", "Delicate ruffle sleeve trim", "Non-pinch soft waistband", "Machine wash warm"]'::jsonb,
  49, 340, 115, true, false, 18
),
(
  'girls-stretch-denim-jeans', 'Girls Comfort Stretch Denim Jeans', 'Super-soft stretch indigo denim',
  'Slim-straight denim jeans designed specifically for comfort. Features an adjustable interior waistband button track.',
  'jeans', 'girls', 'signature-rib', 219000, 'Light Ozone Denim', '#6C8EBF', '94% cotton, 5% polyester, 1% elastane',
  NULL,
  '["https://images.pexels.com/photos/4271568/pexels-photo-4271568.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/7764608/pexels-photo-7764608.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["4-5Y", "6-7Y", "8-9Y", "10-12Y", "13-14Y"]'::jsonb,
  '["Adjustable interior waistband", "4-way stretch denim", "Reinforced 5-pocket construction", "Machine wash cold"]'::jsonb,
  48, 165, 95, false, false, 19
),
(
  'girls-embroidered-knit-sweater', 'Girls Soft Knit Cable Sweater', 'Cozy fine cotton-blend sweater',
  'A classic crewneck sweater knitted with fine cotton yarn and subtle cable stitches. Perfect for cool days and festive occasions.',
  'sweaters', 'girls', 'merino-trail', 229000, 'Cream Ecru', '#F5F1E6', '80% combed cotton, 20% soft viscose',
  'New',
  '["https://images.pexels.com/photos/8346261/pexels-photo-8346261.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/1620760/pexels-photo-1620760.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["4-5Y", "6-7Y", "8-9Y", "10-12Y"]'::jsonb,
  '["Delicate cable knit pattern", "Ultra-soft non-scratchy yarn", "Ribbed cuffs and lower hem", "Hand wash cold"]'::jsonb,
  49, 140, 70, false, true, 20
),

-- KIDS OUTFITS
(
  'kids-organic-knit-set', 'Kids Organic Cotton Duo Set', 'Ultra-gentle organic knitwear',
  'Specially made for sensitive young skin. A matching crew t-shirt and easy-pull sweat shorts in 100% GOTS-certified organic cotton.',
  'kidswear', 'kids', 'signature-rib', 119000, 'Honey & Cream', '#E5BA73', '100% organic combed cotton',
  'Organic',
  '["https://images.pexels.com/photos/1620760/pexels-photo-1620760.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/9775825/pexels-photo-9775825.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["2-3Y", "4-5Y", "6-7Y", "8-9Y"]'::jsonb,
  '["Two pieces included", "Tagless neck print", "Gentle elastic waistband", "Machine wash warm"]'::jsonb,
  48, 240, 140, true, false, 21
),
(
  'kids-cozy-fleece-jumpsuit', 'Kids Terry Fleece Loungewear Set', 'Matching sweatshirt & sweatpants',
  'A head-to-toe fleece set with a comfy crewneck sweater and pull-on elastic waistband sweatpants.',
  'kidswear', 'kids', 'winter-weight', 179000, 'Terracotta Red', '#C05A46', '100% soft combed cotton terry',
  NULL,
  '["https://images.pexels.com/photos/28701960/pexels-photo-28701960.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/6995892/pexels-photo-6995892.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["2-3Y", "4-5Y", "6-7Y", "8-9Y"]'::jsonb,
  '["Includes sweater and sweatpants", "Gentle ribbed wrist & ankle cuffs", "Hypoallergenic organic cotton", "Machine wash warm"]'::jsonb,
  49, 185, 100, false, false, 22
),
(
  'kids-combed-cotton-shorts-pack', 'Kids Combed Cotton Shorts 2-Pack', 'Pack of two casual drawstring shorts',
  'Two pairs of lightweight cotton knit shorts with elastic drawstrings and side slit pockets. Perfect for play, rest, and warm days.',
  'shorts', 'kids', 'studio-move', 129000, 'Olive & Oat Duo', '#8B9A6D', '100% combed cotton jersey',
  '2-Pack',
  '["https://images.pexels.com/photos/6995892/pexels-photo-6995892.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800", "https://images.pexels.com/photos/1620760/pexels-photo-1620760.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"]'::jsonb,
  '["2-3Y", "4-5Y", "6-7Y", "8-9Y"]'::jsonb,
  '["Two pairs of shorts per pack", "Soft elastic waist with drawcord", "Breathable lightweight knit", "Machine wash warm"]'::jsonb,
  48, 155, 120, false, false, 23
)
ON CONFLICT (slug) DO NOTHING;

