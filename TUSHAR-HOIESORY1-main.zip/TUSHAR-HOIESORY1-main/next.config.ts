import type { NextConfig } from "next";

// Your Supabase project host (for product images uploaded from the admin panel).
// Derived from NEXT_PUBLIC_SUPABASE_URL in .env.local.
function supabaseImageHost(): string | null {
  try {
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    return url ? new URL(url).hostname : null;
  } catch {
    return null;
  }
}

const supabaseHost = supabaseImageHost();

const nextConfig: NextConfig = {
  images: {
    // KEEP IN SYNC with src/lib/image-hosts.ts
    remotePatterns: [
      { protocol: "https", hostname: "images.pexels.com" },
      { protocol: "https", hostname: "www.theundone.com" },
      { protocol: "http", hostname: "www.theundone.com" },
      { protocol: "https", hostname: "cdn.shopify.com" },
      ...(supabaseHost
        ? [
            {
              protocol: "https" as const,
              hostname: supabaseHost,
              pathname: "/storage/v1/object/public/**",
            },
          ]
        : []),
    ],
  },
  experimental: {
    // Admin image uploads are sent through Server Actions (default limit is 1 MB).
    serverActions: { bodySizeLimit: "6mb" },
  },
};

export default nextConfig;
